# THE BACKROOMS — an infinite, AI-companion horror prototype

A browser-based (Three.js / WebGL) survival-horror prototype built around four
systems:

1. **Infinite procedural world** with aggressive chunk-cycling (delete what you
   can't see, stream what's ahead) — runs *literally* forever.
2. **AI companion (UNIT-7)** with a passive **Bot Mode** (follow + auto-aim &
   shoot) and an active **Companion Mode** (real-time dialogue + *autonomous
   tactical decisions* powered by Google **gemini-2.5-flash-lite**, with a full
   offline fallback brain).
3. **Hyper-skeletal "Bacteria"/Wire entities** that hunt by **sound and sight**
   with jarring, stop-motion animation and inhuman, procedurally-synthesized
   vocalizations.
4. **A descending narrative** across recognizable levels (Level 0 → 1 → 2),
   told through recovered recorder logs and UNIT-7's glitching, fading memory.

No build step, no art/audio files — geometry, textures, and sound are all
generated procedurally at runtime.

---

## Run it

This uses native ES modules, so it must be served over HTTP (opening
`index.html` from `file://` will be blocked by the browser).

```bash
# from this folder, pick ONE:
python3 -m http.server 8080
#   ...or...
npx serve -l 8080
```

Then open <http://localhost:8080> in a modern desktop browser (Chrome/Edge/
Firefox). Click **BEGIN DESCENT**, then click the screen to lock the mouse.

### Controls
| Action | Key |
| --- | --- |
| Move | `W A S D` |
| Sprint / Jump | `Shift` / `Space` |
| Look | Mouse |
| Flashlight | `F` |
| Interact / read logs / descend | `E` |
| Talk to UNIT-7 (real-time) | `T` or `C` |
| Order Stay / Follow | `G` |
| Pause / close panels | `Esc` |

---

## ⚠ API key & security

The AI companion calls the Generative Language API with model
`gemini-2.5-flash-lite`. **The key is never stored in source code.** You paste it
into the menu and it is saved only in this browser's `localStorage`
(`backrooms.ai.key`).

- If you previously shared/pasted a key in plain text, **treat it as compromised
  and rotate it** in Google AI Studio / Google Cloud.
- The endpoint format (`generativelanguage.googleapis.com/v1beta/models/<model>
  :generateContent?key=...`) is centralized in `src/config.js`. If your key is a
  different provider/format, change `AI.endpoint`/`AI.model` there.
- Leave the field blank to play with the **offline rule-based companion** — the
  game is fully playable without any key.

---

## Architecture

```
backrooms/
├── index.html            # canvas + all DOM overlays (HUD, dialogue, menus)
├── styles.css            # liminal/VHS UI styling
└── src/
    ├── config.js         # tunables + SECURE api-key handling
    ├── main.js           # Game orchestrator, render loop, state machine
    ├── core/Input.js     # keyboard + mouse-look + pointer lock
    ├── util/Rng.js       # deterministic seeded RNG (seamless chunks)
    ├── player/Player.js  # FPS controller, collision, flashlight, vitals
    ├── world/
    │   ├── levels.js     # data-driven Level 0/1/2 definitions
    │   ├── Textures.js   # procedural canvas textures
    │   └── ChunkManager.js   # INFINITE generation + chunk cycling
    ├── entities/
    │   ├── BacteriaEntity.js # skeletal wire monster + hunting AI
    │   └── EntityManager.js  # spawn/cull + threat queries
    ├── companion/
    │   ├── CompanionBrain.js # Gemini integration + offline brain
    │   └── Companion.js      # drone: bot mode + autonomous tactics
    ├── narrative/StoryManager.js  # logs + UNIT-7 memories
    └── ui/HUD.js          # DOM HUD/dialogue/log-reader controller
```

### How "infinite + delete what you can't see" works
The level is an unbounded grid of cells; walls are decided by **hashing each
edge's global coordinates**, so neighbouring chunks always agree on shared walls
(seamless). Each frame `ChunkManager` keeps only a small radius of chunks around
the player **plus a forward bias** in the look direction and *disposes the rest
immediately* (geometry + GPU buffers freed). Turning around rebuilds chunks
byte-identical from their seed. Heavy fog hides the streaming boundary.

> Design note: strict *POV-only* deletion makes the world pop violently when you
> spin and breaks collision behind you, so we use distance + forward-bias culling
> (the standard approach) on top of Three's GPU frustum culling. Same goal —
> tiny working set for infinite scale — without the artefacts.

### Tuning
Most knobs live in `src/config.js` (`CFG`): `viewRadiusChunks`, `chunkSize`,
`fogFar`, movement speeds, companion detection radius, entity hearing/sight, etc.
Per-level aesthetics, wall density, light spacing, and threat rates live in
`src/world/levels.js`.

---

## Where to push toward true "hyper-realism"
This is an engine-agnostic prototype. To reach photoreal fidelity you'd:
- Swap procedural meshes/textures for **PBR assets + a rigged, skinned GLTF**
  Bacteria model with authored, jittery animation clips.
- Add a **post-processing stack** (bloom, SSAO, chromatic aberration, film grain,
  lens distortion) via `postprocessing`/`EffectComposer`.
- Bake/stream real audio stems alongside the procedural layer.
- For console-grade realism, port the same systems to **Unreal (Lumen/Nanite)** —
  the AI, streaming, and narrative designs here translate directly.
