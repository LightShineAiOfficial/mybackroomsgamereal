/* =====================================================================
 * config.js — Global tunables + SECURE API-KEY handling.
 *
 * SECURITY MODEL
 * --------------
 * The AI companion talks to Google's Generative Language API
 * (model: gemini-2.5-flash-lite). The API key is *never* written into
 * source code. Instead:
 *
 *   1. The player pastes it into the main menu field.
 *   2. We persist it in `localStorage` on THIS machine only.
 *   3. It is read back at runtime by CompanionBrain.
 *
 * If the key you originally shared was pasted anywhere public, treat it
 * as compromised and rotate it in the Google AI Studio / Cloud console.
 * ===================================================================== */

const KEY_STORAGE = 'backrooms.ai.key';

export const AI = {
  // REST endpoint template for the Generative Language API.
  endpoint: (model, key) =>
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`,
  model: 'gemini-2.5-flash-lite',
  // Hard cap so a runaway loop can't spam the API.
  minMsIntervalBetweenCalls: 1200,
  maxOutputTokens: 220,

  getKey() {
    try { return localStorage.getItem(KEY_STORAGE) || ''; }
    catch { return ''; }
  },
  setKey(k) {
    try {
      if (k) localStorage.setItem(KEY_STORAGE, k.trim());
      else localStorage.removeItem(KEY_STORAGE);
    } catch { /* private mode — key just won't persist */ }
  },
  hasKey() { return !!this.getKey(); },
};

// ---------------------------------------------------------------------
// Gameplay / engine tunables. Tweak freely for performance vs. fidelity.
// ---------------------------------------------------------------------
export const CFG = {
  // ---- Chunk streaming (infinite world) ----
  chunkSize: 28,           // world units per chunk (square)
  cellsPerChunk: 5,        // maze cells per chunk edge
  get cellSize() { return this.chunkSize / this.cellsPerChunk; },
  viewRadiusChunks: 3,     // chunks kept loaded around the player (radius)
  forwardBiasChunks: 1,    // extra chunks streamed ahead of the look dir
  wallHeight: 3.0,
  worldSeed: 1337,         // base seed; per-level offset applied in levels.js

  // ---- Player ----
  playerHeight: 1.7,
  playerRadius: 0.32,
  walkSpeed: 4.2,
  sprintSpeed: 7.0,
  mouseSensitivity: 0.0022,
  jumpSpeed: 5.2,
  gravity: 16.0,

  // ---- Atmosphere ----
  fogNear: 4,
  fogFar: 34,              // heavy fog hides chunk pop-in + adds dread

  // ---- Weapon (the player fights now; the handler does not) ----
  weapon: {
    magSize: 14,
    damage: 34,
    range: 45,
    fireCooldown: 0.14,    // seconds between shots
    reloadTime: 1.4,
    hitRadius: 0.7,        // forgiving aim against fast horrors
  },

  // ---- Handler comms (UNIT-7 is now a remote overseer, not a drone) ----
  threatAwarenessRadius: 18,   // used to brief the handler on nearby threats

  // ---- Entities ----
  entityHearingRadius: 22,
  entitySightRadius: 30,

  // ---- Horror feedback ----
  proximityRedStart: 11,  // screen starts bleeding red at this distance (m)
  proximityRedFull: 1.6,  // fully red at this distance

  // ---- Performance ----
  pixelRatioCap: 1.5,     // lower = faster (was 2)
  lightPoolSize: 5,       // dynamic point lights chasing fixtures (was 7)

  // ---- Debug ----
  debug: false,
};
