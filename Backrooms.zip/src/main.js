/* =====================================================================
 * main.js — Game orchestrator + render loop + state machine.
 *
 * Owns the Three.js renderer/scene/camera and ties together every system:
 * input, player, the infinite world, entities, the AI companion, audio,
 * narrative, and the HUD. Also wires the menu, pause/death, interaction,
 * and the real-time companion dialogue.
 * ===================================================================== */

import * as THREE from 'three';
import { CFG, AI } from './config.js';
import { Input } from './core/Input.js';
import { Player } from './player/Player.js';
import { ChunkManager } from './world/ChunkManager.js';
import { EntityManager } from './entities/EntityManager.js';
import { AudioManager } from './audio/AudioManager.js';
import { CompanionBrain } from './companion/CompanionBrain.js';
import { StoryManager } from './narrative/StoryManager.js';
import { HUD } from './ui/HUD.js';
import { getLevel, MAX_LEVEL } from './world/levels.js';

class Game {
  constructor() {
    this.canvas = document.getElementById('game-canvas');
    this.state = 'menu';                 // menu | playing | paused | dead
    this.dialogueOpen = false;
    this.logOpen = false;
    this.currentLevelId = 0;
    this.lightingExposure = 0.5;
    this.recentEvents = [];
    this.pendingMemory = null;

    this._initThree();
    this._initSystems();
    this._initMenu();
    this._bindKeys();

    addEventListener('resize', () => this._onResize());
    this.clock = new THREE.Clock();
    this._loop = this._loop.bind(this);
    requestAnimationFrame(this._loop);
  }

  // ---------------------------------------------------------------- Three
  _initThree() {
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, CFG.pixelRatioCap)); // perf knob
    this.renderer.autoClear = false; // we render world + viewmodel in two passes
    this.renderer.setSize(innerWidth, innerHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(76, innerWidth / innerHeight, 0.05, CFG.fogFar + 8);

    // Low fill lighting so corners read as gloom, not pure black.
    this.hemi = new THREE.HemisphereLight(0xffffff, 0x222218, 0.25);
    this.ambient = new THREE.AmbientLight(0xffffff, 0.08);
    this.scene.add(this.hemi); this.scene.add(this.ambient);
  }

  _initSystems() {
    this.input = new Input(this.canvas);
    this.audio = new AudioManager();
    this.player = new Player(this.camera, this.scene);
    this.chunkManager = new ChunkManager(this.scene);
    this.entityManager = new EntityManager(this.scene);
    this.brain = new CompanionBrain();
    this.story = new StoryManager();
    this.hud = new HUD();

    // Hooks the subsystems call back into.
    this.onDamage = () => { this.hud.damageFlash(); this.audio.playHurt(); this._event('took damage'); };
    this.onPlayerDeath = () => this._die();
    this.onCompanionBark = (text, mood) => this._companionBark(text, mood);
    // An entity just locked onto the player at close range → jumpscare.
    this.onEntityLockOn = (e) => {
      const pan = this.audio.panFor(e.position, this.player);
      this.audio.playJumpscare(pan);
      this.hud.damageFlash();
      this._event('an entity locked on');
    };
  }

  // ---------------------------------------------------------------- Menu
  _initMenu() {
    const keyInput = document.getElementById('api-key');
    if (AI.hasKey()) keyInput.value = AI.getKey();

    document.getElementById('start-btn').onclick = () => {
      const k = keyInput.value.trim();
      AI.setKey(k);
      this.brain.refreshKeyState();
      document.getElementById('boot-status').textContent =
        k ? 'AI companion: ONLINE (gemini-2.5-flash-lite)' : 'AI companion: OFFLINE rule-based brain';
      this.audio.init();
      this._startGame();
    };

    document.getElementById('resume-btn').onclick = () => this.resume();
    document.getElementById('quit-btn').onclick = () => location.reload();
    document.getElementById('respawn-btn').onclick = () => this._respawn();
    document.getElementById('log-reader-close').onclick = () => this._closeLog();

    // Dialogue form.
    this.hud.dialogueForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const text = this.hud.dialogueInput.value.trim();
      if (!text) return;
      this.hud.dialogueInput.value = '';
      this._sendToCompanion(text);
    });
  }

  _startGame() {
    document.getElementById('menu').classList.add('hidden');
    this.hud.show();
    this.currentLevelId = 0;
    this.player.ammo = CFG.weapon.magSize; this.player.reloading = false;
    this._loadLevel(0, true);
    this.state = 'playing';
    this.input.requestLock();
  }

  // ---------------------------------------------------------------- Levels
  _loadLevel(levelId, firstSpawn = false) {
    const level = getLevel(levelId);
    this.currentLevelId = levelId;
    this.level = level;

    // Atmosphere.
    const p = level.palette, a = level.atmosphere;
    this.scene.fog = new THREE.Fog(p.fog, a.fogNear, a.fogFar);
    this.scene.background = new THREE.Color(p.fog);
    this.hemi.color.set(p.light); this.hemi.groundColor.set(p.floor);
    this.hemi.intensity = 0.18 + a.ambientLevel; this.ambient.intensity = a.ambientLevel * 0.5;

    // World + entities.
    this.chunkManager.setLevel(level);
    this.entityManager.setLevel(level);

    // Place player at the cleared origin cell.
    const sx = CFG.cellSize * 0.5, sz = CFG.cellSize * 0.5;
    this.player.spawnAt(sx, sz, 0);

    // Build the whole visible neighbourhood before the first frame.
    this.chunkManager.primeAround(this.player.position, this.player.getForwardFlat());

    // Audio + HUD + intro transmission.
    this.audio.startAmbience(level);
    this.hud.setLevel(level);
    const [who, line] = this.story.levelIntro(levelId);
    setTimeout(() => this._companionBark(line, 'wary'), 600);
    this._event('arrived at ' + level.name);
  }

  _descend() {
    if (this.currentLevelId >= MAX_LEVEL) {
      // Narrative ending when there's nothing deeper.
      this._companionBark('The door. It only opens one way. ...Thank you for the company.', 'glitching');
      this.audio.playStinger();
      setTimeout(() => this._ending(), 2500);
      return;
    }
    this.audio.playDescend();
    this.hud.subtitle('', 'You sink through the moist carpet. Reality thins...', 3500);
    this._loadLevel(this.currentLevelId + 1);
  }

  // ---------------------------------------------------------------- Loop
  _loop() {
    requestAnimationFrame(this._loop);
    const dt = Math.min(0.05, this.clock.getDelta());

    if (this.state === 'playing') this._update(dt);

    // Pass 1: the world.
    this.renderer.clear();
    this.renderer.render(this.scene, this.camera);

    // Pass 2: the first-person hazmat viewmodel, on a fresh depth buffer so
    // the gun is never occluded by walls.
    if (this.state === 'playing' || this.state === 'paused') {
      this.renderer.clearDepth();
      this.renderer.render(this.player.viewScene, this.player.viewCamera);
    }
  }

  _update(dt) {
    const player = this.player;

    // Player only steers when not typing in the comms box.
    if (!this.dialogueOpen) player.update(dt, this);
    else player._applyCamera(); // keep camera coherent while on comms

    // Auto-fire while the mouse button is held (fire-rate gated in Player).
    if (this._firing && this._playable()) player.fire(this);

    // Stream the infinite world around (and ahead of) the player.
    this.chunkManager.update(player.position, player.getForwardFlat(), dt);
    this.lightingExposure = this.chunkManager.exposure;

    // Footstep audio synced to head-bob.
    this._footsteps(dt);

    this.entityManager.update(dt, this);
    this.audio.update(dt, this);

    // Interaction prompt.
    if (!this.dialogueOpen && !this.logOpen) this._updateInteract();

    // Horror feedback: screen bleeds red as the nearest entity closes in.
    this._updateProximity();

    // HUD.
    this.hud.setVitals(player.health, player.stamina, player.sanity);
    this.hud.setAmmo(player.ammo, CFG.weapon.magSize, player.reloading);
    const td = this.entityManager.nearestThreatDistance(player.eyePosition);
    this.hud.setComms('UNIT-7 // COMMS LINK',
      td < CFG.threatAwarenessRadius ? `threat ${td.toFixed(0)}m — handler advises caution` : 'handler standing by');
  }

  _updateProximity() {
    const td = this.entityManager.nearestThreatDistance(this.player.eyePosition);
    const s = CFG.proximityRedStart, f = CFG.proximityRedFull;
    const red = td < s ? Math.min(1, (s - td) / (s - f)) : 0;
    this.hud.setProximity(red * 0.92);
  }

  _footsteps(dt) {
    this._stepT = (this._stepT || 0) - dt;
    if (this.player.speed > 0 && this.player.onGround && this._stepT <= 0) {
      this.audio.playFootstep(this.player.speed > CFG.walkSpeed ? 0.14 : 0.08);
      this._stepT = this.player.speed > CFG.walkSpeed ? 0.32 : 0.46;
    }
  }

  _updateInteract() {
    const it = this.chunkManager.nearestInteractable(this.player.position, 1.8);
    this._nearInteractable = it;
    if (!it) return this.hud.showInteract(null);
    this.hud.showInteract(it.type === 'descent' ? '[E] Noclip deeper' : '[E] Recover audio log');
  }

  // ---------------------------------------------------------------- Input
  _bindKeys() {
    const I = this.input;
    I.on('KeyF', () => { if (this._playable()) this.hud.subtitle('', this.player.toggleFlashlight() ? 'flashlight on' : 'flashlight off', 1200); });
    I.on('KeyE', () => this._interact());
    I.on('KeyR', () => { if (this._playable()) this.player.reload(this); });
    I.on('KeyT', () => this._toggleDialogue());
    I.on('KeyC', () => this._toggleDialogue());
    I.on('Escape', () => this._onEscape());

    // Pointer lock loss while playing = pause (unless we did it on purpose).
    I.on('__unlock', () => {
      if (this.state === 'playing' && !this.dialogueOpen && !this.logOpen) this.pause();
    });

    // Mouse: hold left button to fire (fire-rate gated in Player). Pointer lock
    // routes button events to the document, so we listen there.
    document.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      if (this._playable() && this.input.pointerLocked) { this._firing = true; this.player.fire(this); }
    });
    document.addEventListener('mouseup', (e) => { if (e.button === 0) this._firing = false; });
  }

  _playable() { return this.state === 'playing' && !this.dialogueOpen && !this.logOpen; }

  _interact() {
    if (this.logOpen) return this._closeLog();
    if (!this._playable()) return;
    const it = this._nearInteractable;
    if (!it) return;
    if (it.type === 'descent') { this._descend(); return; }
    if (it.type === 'log' && !it.used) {
      it.used = true; it.mesh.visible = false;
      this.audio.playPickup();
      const { log, memory } = this.story.onLogFound(it.logIndex);
      this._openLog(log.title, log.body);
      if (memory) this.pendingMemory = memory; // surfaced after the player closes it
      this._event('recovered log: ' + log.title);
    }
  }

  _openLog(title, body) {
    this.logOpen = true;
    this.input.exitLock();
    this.input.enabled = false;
    this.hud.openLog(title, body);
  }
  _closeLog() {
    if (!this.logOpen) return;
    this.logOpen = false;
    this.hud.closeLog();
    this.input.enabled = true;
    if (this.state === 'playing') this.input.requestLock();
    if (this.pendingMemory) {
      const mem = this.pendingMemory; this.pendingMemory = null;
      setTimeout(() => this._companionBark(mem.replace(/^UNIT-7:\s*/, ''), 'glitching'), 900);
    }
  }

  _onEscape() {
    if (this.logOpen) return this._closeLog();
    if (this.dialogueOpen) return this._toggleDialogue();
    if (this.state === 'playing') this.pause();
    else if (this.state === 'paused') this.resume();
  }

  // ---------------------------------------------------------------- Dialogue
  _toggleDialogue() {
    if (this.state !== 'playing') return;
    this.dialogueOpen ? this._closeDialogue() : this._openDialogue();
  }

  _openDialogue() {
    this.dialogueOpen = true;
    this.input.exitLock();
    this.input.enabled = false;
    this.input.releaseAll();
    this._firing = false;
    this.hud.openDialogue();
    if (!this._dialogueGreeted) {
      this._dialogueGreeted = true;
      this.hud.addMessage('sys', 'Comms link to handler UNIT-7 open. The Backrooms do not pause while you talk.');
    }
    this.hud.setQuickReplies(
      ['Where do I go?', 'How do I survive these things?', 'Take me to the next level.', 'Who are you?', 'I need a clue.'],
      (r) => this._sendToCompanion(r));
  }

  _closeDialogue() {
    this.dialogueOpen = false;
    this.hud.closeDialogue();
    this.input.enabled = true;
    if (this.state === 'playing') this.input.requestLock();
  }

  async _sendToCompanion(text) {
    this.hud.addMessage('you', text);
    const typing = this.hud.addTyping();
    const r = await this.brain.respond(this._buildCtx(), text);
    typing.classList.remove('typing');
    typing.textContent = r.say;
    this.hud.dialogueLog.scrollTop = this.hud.dialogueLog.scrollHeight;

    // The handler (your "boss") can authorize a descent on request — this is
    // the deliberate "get me out / next level" route. We also detect the
    // intent locally so it works even on the offline brain.
    const descend = r.action === 'descend' || CompanionBrain.wantsDescent(text);
    if (descend) {
      this.hud.addMessage('sys', 'UNIT-7 authorizes a noclip descent. Stand by…');
      this.hud.subtitle('UNIT-7', r.say, 3000);
      setTimeout(() => { if (this.dialogueOpen) this._closeDialogue(); this._descend(); }, 1600);
      return;
    }
    if (r.action && r.action !== 'none') {
      this.hud.addMessage('sys', `handler intent → ${r.action.toUpperCase()} (${r.source}, mood: ${r.mood})`);
    }
    this.hud.subtitle('UNIT-7', r.say, 4500);
  }

  _buildCtx() {
    const eye = this.player.eyePosition;
    const near = this.entityManager.threatsInRadius(eye, CFG.threatAwarenessRadius);
    return {
      level: this.level.name,
      health: Math.round(this.player.health),
      sanity: Math.round(this.player.sanity),
      detectRadius: CFG.threatAwarenessRadius,
      threatsNear: near.length,
      nearestThreat: near.length ? near[0].dist.toFixed(1) + 'm' : 'none',
      ammo: this.player.ammo,
      recent: this.recentEvents.slice(-4).join('; '),
    };
  }

  _companionBark(text, mood = 'wary') {
    this.hud.subtitle('UNIT-7', text, 5000);
    if (this.dialogueOpen) this.hud.addMessage('unit', text);
  }

  _event(s) { this.recentEvents.push(s); if (this.recentEvents.length > 12) this.recentEvents.shift(); }

  // ---------------------------------------------------------------- States
  pause() {
    if (this.state !== 'playing') return;
    this.state = 'paused';
    this.input.releaseAll();
    document.getElementById('pause').classList.remove('hidden');
    this.audio.setMasterVolume(0.2);
  }
  resume() {
    if (this.state !== 'paused') return;
    document.getElementById('pause').classList.add('hidden');
    this.state = 'playing';
    this.audio.setMasterVolume(0.6);
    this.input.requestLock();
  }

  _die() {
    this.state = 'dead';
    this.input.exitLock();
    document.getElementById('death').querySelector('h2').textContent = 'YOU HAVE BEEN UNALIVED';
    const flavor = [
      'The clicking stopped. So did you.',
      'No-clip failed. The walls kept you.',
      'UNIT-7 logged your final coordinates. Then it kept walking.',
    ];
    document.getElementById('death-flavor').textContent = flavor[Math.floor(Math.random() * flavor.length)];
    document.getElementById('death').classList.remove('hidden');
    this.audio.playStinger();
  }

  _respawn() {
    document.getElementById('death').classList.add('hidden');
    document.getElementById('death').querySelector('h2').textContent = 'YOU HAVE BEEN UNALIVED';
    this.player.health = 100; this.player.stamina = 100; this.player.sanity = 70; this.player.alive = true;
    this.player.ammo = CFG.weapon.magSize; this.player.reloading = false;
    this.currentLevelId = 0;
    this._loadLevel(0, true);
    this.state = 'playing';
    this.input.requestLock();
  }

  _ending() {
    this.state = 'dead';
    this.input.exitLock();
    document.getElementById('death').querySelector('h2').textContent = 'YOU FOUND THE DOOR';
    document.getElementById('death-flavor').textContent =
      'It only opened one way. UNIT-7 stayed behind so you wouldn\'t. Maybe that\'s the whole story.';
    document.getElementById('death').classList.remove('hidden');
  }

  _onResize() {
    this.camera.aspect = innerWidth / innerHeight;
    this.camera.updateProjectionMatrix();
    if (this.player?.viewCamera) {
      this.player.viewCamera.aspect = innerWidth / innerHeight;
      this.player.viewCamera.updateProjectionMatrix();
    }
    this.renderer.setSize(innerWidth, innerHeight);
  }
}

// Boot.
window.addEventListener('DOMContentLoaded', () => { window.__game = new Game(); });
