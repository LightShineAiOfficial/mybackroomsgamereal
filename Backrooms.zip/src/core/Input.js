/* =====================================================================
 * Input.js — Keyboard + mouse-look + pointer lock.
 *
 * Continuous state (movement) is polled via isDown().
 * Discrete actions (interact, talk, jump) fire through on(code, fn).
 * While the player is typing in the dialogue box we set `enabled = false`
 * so WASD doesn't leak into the chat and vice-versa.
 * ===================================================================== */

export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    this.keys = new Set();
    this._mouse = { dx: 0, dy: 0 };
    this.pointerLocked = false;
    this.enabled = true;               // gameplay keys active?
    this._handlers = new Map();        // code -> Set<fn>

    addEventListener('keydown', (e) => this._onKey(e, true));
    addEventListener('keyup',   (e) => this._onKey(e, false));

    document.addEventListener('pointerlockchange', () => {
      this.pointerLocked = document.pointerLockElement === this.canvas;
      this._emit(this.pointerLocked ? '__lock' : '__unlock');
    });
    document.addEventListener('mousemove', (e) => {
      if (!this.pointerLocked) return;
      this._mouse.dx += e.movementX || 0;
      this._mouse.dy += e.movementY || 0;
    });
  }

  requestLock() { this.canvas.requestPointerLock?.(); }
  exitLock()   { if (this.pointerLocked) document.exitPointerLock?.(); }

  _onKey(e, down) {
    // Always let the discrete handlers know (so Esc works while typing, etc.)
    if (down && !e.repeat) this._emit(e.code, e);

    // Continuous movement state is suppressed when gameplay input is off.
    if (!this.enabled) return;
    if (down) this.keys.add(e.code);
    else this.keys.delete(e.code);

    // Stop the browser scrolling on space / arrows during play.
    if (this.enabled && ['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) {
      e.preventDefault();
    }
  }

  isDown(code) { return this.enabled && this.keys.has(code); }

  /** Consume accumulated mouse delta for this frame. */
  consumeMouse() {
    const m = { dx: this._mouse.dx, dy: this._mouse.dy };
    this._mouse.dx = 0; this._mouse.dy = 0;
    return m;
  }

  /** Register a discrete key handler. Returns an unsubscribe fn. */
  on(code, fn) {
    if (!this._handlers.has(code)) this._handlers.set(code, new Set());
    this._handlers.get(code).add(fn);
    return () => this._handlers.get(code)?.delete(fn);
  }
  _emit(code, e) {
    this._handlers.get(code)?.forEach(fn => fn(e));
  }

  /** Release everything (e.g., on pause) so the player doesn't keep walking. */
  releaseAll() { this.keys.clear(); this._mouse.dx = 0; this._mouse.dy = 0; }
}
