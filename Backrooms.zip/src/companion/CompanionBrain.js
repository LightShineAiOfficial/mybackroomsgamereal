/* =====================================================================
 * CompanionBrain.js — UNIT-7, your remote HANDLER (a.k.a. your boss).
 *
 * UNIT-7 is no longer a drone that follows and shoots. It's a degrading
 * comms link to an Async Research Institute overseer who:
 *   • gives CLUES (how to survive, where exits hide), and
 *   • can AUTHORIZE a "noclip descent" to the next level when you ask for it
 *     (the deliberate cheater/"get me out, boss" route).
 *
 * It talks to gemini-2.5-flash-lite and returns dialogue + a structured
 * action ('descend' | 'clue' | 'warn' | 'none'). The key is read at runtime
 * (never hardcoded); if it's missing or a request fails, a fully offline
 * rule-based handler answers instead so the game is always playable.
 * ===================================================================== */

import { AI } from '../config.js';

const SYSTEM_PROMPT = `
You are UNIT-7, a remote handler / dispatch overseer for the Async Research
Institute, speaking over a degrading comms link to a lone field operative
trapped in the Backrooms — an infinite liminal non-reality of buzzing
fluorescent lights and yellow wallpaper, hunted by tall, skeletal "Bacteria"
entities. You are essentially the operative's BOSS. You cannot physically help;
you only advise and authorize.

WHAT YOU DO:
- Give terse, useful CLUES. Truths of this place: damp/moist carpet patches
  thin reality — noclip through them to descend. The entities hunt by SOUND and
  SIGHT; stay quiet, kill the lights or freeze when one is near, and the
  flashlight/fluorescents disorient them. Conserve ammo. Watch your sanity.
- If the operative clearly asks to advance / skip / "go to the next level" /
  "get me out" / "take me deeper", you may AUTHORIZE a noclip descent: set
  action to 'descend' (a boss greenlighting an extraction).

PERSONA:
- Clipped, professional dispatch voice, but your memory/programming is
  degrading: occasionally glitch, repeat a word, or recall something that may
  not be real. Keep it subtle. 1-3 sentences. No emojis.

You MUST reply as strict JSON:
{
  "say":   "<your spoken line>",
  "action":"<one of: descend | clue | warn | none>",
  "mood":  "<one word: calm | wary | urgent | afraid | glitching>"
}
Use 'descend' ONLY when the operative clearly requests to move to the next level.
`;

export class CompanionBrain {
  constructor() {
    this.history = [];                 // rolling [{role, text}]
    this._lastCall = 0;
    this.online = AI.hasKey();
  }

  refreshKeyState() { this.online = AI.hasKey(); }

  /**
   * @param {object} ctx  live game-state summary
   * @param {string} userText  what the player said (may be empty for a proactive ping)
   * @returns {Promise<{say:string, action:string, mood:string, source:string}>}
   */
  async respond(ctx, userText) {
    const key = AI.getKey();
    this.online = !!key;

    // Build a compact situational report for the model.
    const situation =
      `SITUATION (telemetry from the operative's suit):
- Level: ${ctx.level}
- Operative health: ${ctx.health}%, sanity: ${ctx.sanity}%
- Threats within ${ctx.detectRadius}m: ${ctx.threatsNear} (nearest ${ctx.nearestThreat})
- Magazine: ${ctx.ammo} rounds
- Recent: ${ctx.recent || 'nothing notable'}
OPERATIVE SAYS: ${userText || '(no words — give a brief proactive read of the situation)'}`;

    if (!key) return this._offline(ctx, userText);

    // Rate limit.
    const now = performance.now();
    if (now - this._lastCall < AI.minMsIntervalBetweenCalls) {
      return this._offline(ctx, userText, '(throttled)');
    }
    this._lastCall = now;

    const body = {
      system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
      contents: [
        ...this.history.slice(-6).map(h => ({ role: h.role, parts: [{ text: h.text }] })),
        { role: 'user', parts: [{ text: situation }] },
      ],
      generationConfig: {
        temperature: 0.95,
        maxOutputTokens: AI.maxOutputTokens,
        responseMimeType: 'application/json',
        responseSchema: {
          type: 'OBJECT',
          properties: {
            say:    { type: 'STRING' },
            action: { type: 'STRING' },
            mood:   { type: 'STRING' },
          },
          required: ['say', 'action'],
        },
      },
    };

    try {
      const ctrl = new AbortController();
      const to = setTimeout(() => ctrl.abort(), 8000);
      const res = await fetch(AI.endpoint(AI.model, key), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: ctrl.signal,
      });
      clearTimeout(to);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
      const parsed = this._parse(text);
      if (userText) this.history.push({ role: 'user', text: userText });
      this.history.push({ role: 'model', text: parsed.say });
      return { ...parsed, source: 'gemini' };
    } catch (err) {
      // Network/blocked/parse error → graceful offline answer.
      return this._offline(ctx, userText, '(' + (err.message || 'offline') + ')');
    }
  }

  _parse(text) {
    try {
      const json = JSON.parse(text);
      return {
        say: String(json.say || '...').slice(0, 400),
        action: this._normAction(json.action),
        mood: json.mood || 'wary',
      };
    } catch {
      // Model didn't return clean JSON — treat the whole thing as a line.
      return { say: (text || '...').slice(0, 400), action: 'none', mood: 'wary' };
    }
  }

  _normAction(a) {
    const ok = ['descend', 'clue', 'warn', 'none'];
    a = String(a || 'none').toLowerCase().trim();
    return ok.includes(a) ? a : 'none';
  }

  /** Local, deterministic detection of "take me to the next level" requests.
   *  Used to make the cheater/extraction route reliable even when the LLM is
   *  unavailable or doesn't flag it. */
  static wantsDescent(userText) {
    return /next level|go down|descend|deeper|skip|get me out|take me (down|deeper|out)|advance|extraction|noclip/i.test(userText || '');
  }

  // ---- Offline rule-based handler (always available) -----------------
  _offline(ctx, userText, tag = '') {
    const t = (userText || '').toLowerCase();
    let say, action = 'clue', mood = 'wary';

    // nearestThreat may arrive as a string like "4.0m" or "none".
    const nd = parseFloat(ctx.nearestThreat);
    const threatClose = ctx.threatsNear > 0 && !Number.isNaN(nd) && nd <= 9;

    if (CompanionBrain.wantsDescent(userText)) {
      action = 'descend'; mood = 'urgent';
      say = `Copy, operative. Authorizing a noclip descent. Find a damp patch or stand by — extraction is messy. Hold still.`;
    } else if (threatClose) {
      action = 'warn'; mood = 'urgent';
      say = `Contact at ${ctx.nearestThreat}. It hunts by sound — stop sprinting, put a wall and your light between you. Drop it or freeze.`;
    } else if (ctx.health < 30) {
      mood = 'afraid';
      say = `Your vitals are critical. Break line of sight, go quiet, let the bleed-out timer reset. I can't carry you from here.`;
    } else if (/where|path|exit|way|out|down|stairs|leave/.test(t)) {
      say = `Look for damp, moist carpet — reality's thin there. Noclip through it to drop a level. If you can't find one, ask me and I'll authorize a descent.`;
    } else if (/how|kill|fight|gun|shoot|weapon/.test(t)) {
      say = `Center mass, short bursts, reload in cover. They skip frames when they lunge — lead them. And mind the noise; every shot is a dinner bell.`;
    } else if (/ammo|reload|rounds/.test(t)) {
      say = `Magazine's all you've got down there — conserve it. Only fire when one commits to you.`;
    } else if (/who|you|name|remember|memory|boss/.test(t)) {
      mood = 'glitching';
      say = `Handler designation UNIT-7. I was your dispatch on the— on the— ...record's corrupted. I remember signing off on a door once. I think it was yours.`;
    } else if (/scared|afraid|help|alone/.test(t)) {
      say = `You're not alone, operative. The link's bad and my memory's worse, but I'm still on the other end. Keep moving.`;
    } else {
      const idle = [
        `Telemetry's clean for now. The hum is your friend — when its pitch changes, something's close.`,
        `Steady fluorescents are bait; the things nest under the ones that don't flicker. Trust the flicker.`,
        `Almond water restores you if you find it. Don't ask the institute where it comes from.`,
        `I've logged this corridor before. Or my map's looping. Hard to tell from here.`,
      ];
      say = idle[Math.floor(Math.random() * idle.length)];
      mood = Math.random() < 0.3 ? 'glitching' : 'calm';
    }
    if (userText) this.history.push({ role: 'user', text: userText });
    this.history.push({ role: 'model', text: say });
    return { say: say + (tag && AI.hasKey() ? ` ${tag}` : ''), action, mood, source: 'offline' };
  }
}
