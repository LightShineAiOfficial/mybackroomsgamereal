/* =====================================================================
 * StoryManager.js — Environmental storytelling + UNIT-7's fading memory.
 *
 * The arc is discovered, never narrated: recovered recorder logs scattered
 * by the generator, level-entry transmissions, and glitched memory fragments
 * UNIT-7 surfaces as you descend. Nothing here blocks gameplay; it layers
 * dread and meaning on top of it.
 * ===================================================================== */

export class StoryManager {
  constructor() {
    this.logsFound = 0;
    this.seenLogIndices = new Set();
    this.memoryStage = 0;
  }

  reset() { /* progression persists across levels by design */ }

  // Transmission shown when arriving at a level.
  levelIntro(levelId) {
    return ({
      0: ['UNIT-7', 'Boot complete. We... noclipped. This is not a drill. Find the damp carpet — it thins reality. We go down.'],
      1: ['UNIT-7', 'Level 1. Habitable, they called it. The M.E.G. left supplies here once. The aisles eat sound. Stay close.'],
      2: ['UNIT-7', 'Pipe Dreams. It is hot, and it is awake. My pathfinding keeps... keeps... rerouting. Do not trust the silence.'],
    })[levelId] || ['UNIT-7', 'Deeper. Always deeper.'];
  }

  // Deterministic recorder log from a generator-supplied index.
  getLog(index) {
    const i = Math.abs(index) % LOGS.length;
    return LOGS[i];
  }

  onLogFound(index) {
    this.logsFound++;
    this.seenLogIndices.add(index);
    const log = this.getLog(index);
    // Every few logs, UNIT-7 dredges up a corrupted memory.
    let memory = null;
    if (this.logsFound % 2 === 0 && this.memoryStage < MEMORIES.length) {
      memory = MEMORIES[this.memoryStage++];
    }
    return { log, memory };
  }
}

// --- Recovered audio logs (original lore in the Kane-Pixels register) ----
const LOGS = [
  { title: 'TAPE 04 — "almond water"',
    body: `[hiss] ...third day. The water from the machine tastes like almonds and\nit's the only thing keeping the headaches down. Sokolov was right.\nIf you find a bottle — drink it. Don't think about where it comes from.\n[a long, low hum] ...it found Reyes by the sound of his recorder. So I'm\nwhispering now. I'm whispering everyth—[CLICK]` },
  { title: 'LOG 11 — Async Research, internal',
    body: `We did not "discover" the level. We fell out of the floor of our own\nbuilding during the 1996 stabilization test. The thing in the walls is\nnot native. We think it followed the signal in.\nDirective stands: do not transmit. It hunts the transmission.` },
  { title: 'NOTE — scrawled on wallpaper',
    body: `IF YOU CAN READ THIS YOU STILL HAVE EYES.\nthe lights that flicker are safe. the lights that DON'T are bait.\nit waits under the steady ones.\ncount the hum. when the hum changes pitch, RUN.` },
  { title: 'TAPE 19 — Sokolov',
    body: `The companion units were a mistake of mercy. We gave them enough mind\nto keep us company and not enough to understand what they're trapped in.\nUnit-7 keeps asking about a door. There is no door in its file.\nI think it's remembering one of ours.` },
  { title: 'LOG 27 — M.E.G. survey',
    body: `Major Explorer Group, marking Level 1.\nWe lost two to the Bacteria in the grey aisles. They don't roar — they\nclick, like a tongue against teeth, and then they're just... already on you.\nWe left water and a sidearm at the pillar. If you're reading this, it's\nyours now. We didn't make it back.` },
  { title: 'TAPE 33 — last entry',
    body: `[breathing] I've been walking for what the recorder says is nine days.\nI passed my own footprints an hour ago. Or someone wearing my shoes.\nThe yellow doesn't end. It was never going to end.\nTell my— there's no one to tell. [the hum rises] oh. oh it's the pitc—[END]` },
  { title: 'PRINTOUT — entity profile',
    body: `DESIGNATION: "Bacteria" (informal). Wire/Virus morphology.\nLOCOMOTION: erratic; appears to skip frames of reality.\nSENSORY: acute hearing; line-of-sight lock at range.\nVOCALIZATION: non-human, sub-vocal clicks + formant scream on contact.\nCOUNTERMEASURE: light disrupts it. Sound attracts it. Do the math.` },
  { title: 'NOTE — UNIT diagnostic slip',
    body: `companion integrity 61%. memory sectors degrading.\nrecommend decommission.\n[handwritten below:] no. it carried Hwang's kid two levels up on a dead\nbattery. it stays. — D.S.` },
];

// --- UNIT-7's fading memories, surfaced as the player goes deeper -------
const MEMORIES = [
  `UNIT-7: I just got a fragment. A corridor that isn't yellow. White. Clean. ...I think that was before.`,
  `UNIT-7: There's a name in my cache I can't delete. "Hwang." I don't have a record of a Hwang. Why do I miss them?`,
  `UNIT-7: I keep dreaming — do I dream? — of carrying something warm up a staircase that goes the wrong way.`,
  `UNIT-7: My boot log says I was activated to "escort survivors out." Plural. You're the only one left, aren't you. ...Aren't you.`,
  `UNIT-7: I found the door in my memory. It's the one we noclipped through. It only opens one way. I'm sorry.`,
];
