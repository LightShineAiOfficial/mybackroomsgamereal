/* =====================================================================
 * BacteriaEntity.js — "The Bacteria" / Wire entity (Kane-Pixels-inspired).
 *
 * A skeletal, distorted thing built procedurally from elongated limbs and
 * trailing "wires". It moves WRONG: stop-motion lunges, limb spasms, and
 * sudden rotational snaps — the uncanny, jarring motion that reads as
 * non-human even in peripheral vision.
 *
 * HUNTING (requirement #3): it perceives the player via
 *   • HEARING — the player's emitted noiseLevel attenuated by distance, and
 *   • SIGHT   — within range, roughly in front, and with a clear wall line.
 * Losing the player drops it into INVESTIGATE toward the last known spot.
 *
 * (For true hyper-realism you'd swap the procedural mesh for a rigged,
 *  skinned GLTF + animation clips; the AI/behaviour here is engine-agnostic.)
 * ===================================================================== */

import * as THREE from 'three';
import { CFG } from '../config.js';
import { clamp } from '../util/Rng.js';

const STATE = { WANDER: 'wander', INVESTIGATE: 'investigate', CHASE: 'chase', ATTACK: 'attack', DYING: 'dying' };

let _mats = null;
function materials() {
  if (_mats) return _mats;
  _mats = {
    bone: new THREE.MeshStandardMaterial({ color: 0x20211f, roughness: 0.85, metalness: 0.15 }),
    skin: new THREE.MeshStandardMaterial({ color: 0x3a302c, roughness: 0.6, metalness: 0.05, transparent: true, opacity: 0.96 }),
    eye:  new THREE.MeshBasicMaterial({ color: 0xff2a14 }),
  };
  return _mats;
}

export class BacteriaEntity {
  constructor(scene, position) {
    this.scene = scene;
    this.position = position.clone();
    this.position.y = 0;
    this.facing = Math.random() * Math.PI * 2;
    this.hp = 100;
    this.alive = true;
    this.isThreat = true;
    this.state = STATE.WANDER;

    this.lastKnownPlayer = null;     // Vector3 of last perceived player pos
    this.attackCooldown = 0;
    this.vocalTimer = Math.random() * 4;
    this.stutter = 0;                // stop-motion lunge phase
    this.spasm = 0;
    this._t = Math.random() * 10;
    this._dyingT = 0;
    this._wasChasing = false;
    // Per-instance height variation — some loom taller than others.
    this.scaleVar = 0.95 + Math.random() * 0.3;
    this.height = 3.0 * this.scaleVar;

    this._build();
  }

  _build() {
    const m = materials();
    this.root = new THREE.Group();
    this.root.position.copy(this.position);
    this.root.scale.setScalar(this.scaleVar);

    // TALL, lanky, lightly-hunched torso (~3m creature).
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.17, 1.25, 5, 10), m.skin);
    torso.position.y = 2.05; torso.rotation.x = 0.32;
    this.root.add(torso);
    this.torso = torso;

    // Distorted, elongated skull thrust forward at the top.
    const head = new THREE.Mesh(new THREE.IcosahedronGeometry(0.21, 1), m.bone);
    head.scale.set(0.78, 1.4, 1.5);
    head.position.set(0, 2.78, 0.24);
    this.root.add(head);
    this.head = head;

    const eyeGeo = new THREE.SphereGeometry(0.04, 6, 6);
    for (const sx of [-1, 1]) {
      const e = new THREE.Mesh(eyeGeo, m.eye);
      e.position.set(0.075 * sx, 2.8, 0.42);
      this.root.add(e);
    }

    // Long spindly limbs (pivoted at the joint so they flail from the joint).
    this.limbs = [];
    const addLimb = (x, y, z, len, baseRot) => {
      const pivot = new THREE.Group();
      pivot.position.set(x, y, z);
      const seg = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.022, len, 6), m.bone);
      seg.position.y = -len / 2;                 // hang down from pivot
      const fore = new THREE.Group();            // second segment for a "knee"/"elbow"
      fore.position.y = -len;
      const seg2 = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.012, len * 0.95, 6), m.bone);
      seg2.position.y = -len * 0.48;
      fore.add(seg2);
      pivot.add(seg); pivot.add(fore);
      pivot.rotation.copy(baseRot);
      pivot.userData = { fore, baseRot: baseRot.clone(), len };
      this.root.add(pivot);
      this.limbs.push(pivot);
    };
    addLimb(-0.22, 2.5, 0.04, 1.3, new THREE.Euler(0.25, 0,  0.45));  // long arms
    addLimb( 0.22, 2.5, 0.04, 1.3, new THREE.Euler(0.25, 0, -0.45));
    addLimb(-0.13, 1.55, 0,   1.5, new THREE.Euler(0.08, 0,  0.12));  // long legs
    addLimb( 0.13, 1.55, 0,   1.5, new THREE.Euler(0.08, 0, -0.12));

    // Trailing "wires" off the back.
    for (let i = 0; i < 4; i++) {
      const w = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.004, 1.5, 4), m.bone);
      w.position.set((Math.random() - 0.5) * 0.22, 1.9, -0.22 - i * 0.05);
      w.rotation.x = 1.3 + Math.random() * 0.35;
      this.root.add(w);
    }
    this.scene.add(this.root);
  }

  // --- perception ------------------------------------------------------
  _perceive(game) {
    const player = game.player;
    if (!player.alive) return { sees: false, hears: 0 };
    const pe = player.eyePosition;
    const dx = pe.x - this.position.x, dz = pe.z - this.position.z;
    const dist = Math.hypot(dx, dz);

    // Hearing: player's noise attenuated by distance, ignores walls.
    let heard = 0;
    if (dist < CFG.entityHearingRadius) {
      heard = player.noiseLevel * (1 - dist / CFG.entityHearingRadius);
    }

    // Sight: in range, in a forward-ish arc, and unobstructed by walls.
    let sees = false;
    if (dist < CFG.entitySightRadius) {
      const toX = dx / (dist || 1), toZ = dz / (dist || 1);
      const fwdX = Math.sin(this.facing), fwdZ = Math.cos(this.facing);
      const facingDot = toX * fwdX + toZ * fwdZ;
      const clear = game.chunkManager.segmentClear(this.position.x, this.position.z, pe.x, pe.z);
      // Wide cone, and it can always "feel" you if you're very close.
      if (clear && (facingDot > -0.2 || dist < 4)) sees = true;
    }
    return { sees, hears: heard, dist, dirX: dx, dirZ: dz };
  }

  // --- main update -----------------------------------------------------
  update(dt, game) {
    this._t += dt;
    if (this.state === STATE.DYING) return this._updateDying(dt);

    const p = this._perceive(game);
    this.attackCooldown -= dt;
    this.vocalTimer -= dt;
    const wasChasing = this.state === STATE.CHASE || this.state === STATE.ATTACK;

    // ---- state transitions ----
    if (p.sees) {
      this.state = (p.dist < 1.6) ? STATE.ATTACK : STATE.CHASE;
      this.lastKnownPlayer = game.player.eyePosition.clone();
    } else if (p.hears > 0.25) {
      this.state = STATE.INVESTIGATE;
      this.lastKnownPlayer = game.player.eyePosition.clone();
    } else if (this.state === STATE.CHASE || this.state === STATE.ATTACK) {
      // Lost sight → go look where you last saw them.
      this.state = this.lastKnownPlayer ? STATE.INVESTIGATE : STATE.WANDER;
    }

    // ---- lock-on jumpscare: it just acquired you at close range ----
    const nowChasing = this.state === STATE.CHASE || this.state === STATE.ATTACK;
    if (nowChasing && !wasChasing && p.dist < 12) game.onEntityLockOn?.(this);

    // ---- behaviour ----
    let speed = 0, target = null;
    switch (this.state) {
      case STATE.CHASE:
        speed = 6.2; target = game.player.eyePosition; break;
      case STATE.ATTACK:
        speed = 1.5; target = game.player.eyePosition;
        if (this.attackCooldown <= 0 && p.dist < 1.8) {
          game.player.takeDamage(16, game);
          game.audio.playStinger();
          this.attackCooldown = 1.1;
          this.spasm = 1;
        }
        break;
      case STATE.INVESTIGATE:
        speed = 2.6; target = this.lastKnownPlayer;
        if (target && Math.hypot(target.x - this.position.x, target.z - this.position.z) < 1.2) {
          this.lastKnownPlayer = null; this.state = STATE.WANDER;
        }
        break;
      default: // WANDER
        speed = 1.1;
        if (!this._wanderTarget || this._t > this._wanderUntil) {
          const sp = game.chunkManager.spawnPointAwayFrom(this.position, 3, null) || this.position;
          this._wanderTarget = sp; this._wanderUntil = this._t + 3 + Math.random() * 3;
        }
        target = this._wanderTarget;
    }

    if (target) this._moveToward(target, speed, dt, game);

    // ---- vocalizations (panned by position) ----
    if (this.vocalTimer <= 0) {
      const chasing = this.state === STATE.CHASE || this.state === STATE.ATTACK;
      const pan = game.audio.panFor(this.position, game.player);
      game.audio.playMonsterVocal(pan, chasing ? 1.3 : 0.7);
      this.vocalTimer = chasing ? 1.2 + Math.random() : 4 + Math.random() * 4;
    }

    this._animate(dt);
  }

  _moveToward(target, speed, dt, game) {
    const dx = target.x - this.position.x, dz = target.z - this.position.z;
    const dist = Math.hypot(dx, dz) || 1;
    this.facing = Math.atan2(dx, dz);

    // Stop-motion stutter: lunge in bursts, then freeze (uncanny gait).
    this.stutter += dt * (this.state === STATE.CHASE ? 7 : 3);
    const gate = (Math.sin(this.stutter) > -0.2) ? 1 : 0.05;

    const step = speed * gate * dt;
    const nx = (dx / dist) * step, nz = (dz / dist) * step;

    // Axis-separated collision against walls.
    this._tryMove(nx, 0, game);
    this._tryMove(0, nz, game);
    this.root.position.copy(this.position);
  }

  _tryMove(dx, dz, game) {
    const r = 0.3;
    let x = this.position.x + dx, z = this.position.z + dz;
    for (const c of game.chunkManager.collidersNear(x, z)) {
      const cx = clamp(x, c.minX, c.maxX), cz = clamp(z, c.minZ, c.maxZ);
      const ddx = x - cx, ddz = z - cz, d2 = ddx * ddx + ddz * ddz;
      if (d2 < r * r) {
        const d = Math.sqrt(d2) || 0.0001;
        x += (ddx / d) * (r - d); z += (ddz / d) * (r - d);
      }
    }
    this.position.x = x; this.position.z = z;
  }

  // --- jarring animation ----------------------------------------------
  _animate(dt) {
    this.root.rotation.y = this.facing;
    this.spasm = Math.max(0, this.spasm - dt * 2);

    const fast = this.state === STATE.CHASE || this.state === STATE.ATTACK;
    const f = fast ? 16 : 6;

    // Limbs flail with high-frequency noise around their base pose.
    for (let i = 0; i < this.limbs.length; i++) {
      const L = this.limbs[i], u = L.userData;
      const ph = this._t * f + i * 1.7;
      const jitter = (Math.random() - 0.5) * (fast ? 0.5 : 0.15);
      L.rotation.x = u.baseRot.x + Math.sin(ph) * 0.5 + jitter + this.spasm * (Math.random() - 0.5);
      L.rotation.z = u.baseRot.z + Math.cos(ph * 0.7) * 0.35;
      u.fore.rotation.x = Math.sin(ph * 1.3) * 0.6 + 0.4;
    }
    // Head twitch + occasional whole-body rotational SNAP.
    this.head.rotation.z = Math.sin(this._t * 9) * 0.2 + (Math.random() - 0.5) * 0.1 * (fast ? 1 : 0.3);
    this.torso.position.y = 1.35 + Math.sin(this._t * f * 0.5) * 0.04;
    if (fast && Math.random() < 0.02) this.root.rotation.y += (Math.random() - 0.5) * 0.6; // snap
  }

  _updateDying(dt) {
    this._dyingT += dt;
    const s = Math.max(0, 1 - this._dyingT * 1.5);
    this.root.scale.setScalar(s);
    this.root.rotation.z += dt * 6;
    this.root.position.y = -this._dyingT * 0.5;
    if (this._dyingT > 0.8) { this.dispose(); this.alive = false; this.isThreat = false; }
  }

  takeDamage(dmg, game) {
    if (this.state === STATE.DYING) return;
    this.hp -= dmg;
    this.spasm = 1;
    // Hit reaction: it notices where it's being shot from.
    this.lastKnownPlayer = game?.player?.eyePosition?.clone() ?? this.lastKnownPlayer;
    if (this.state === STATE.WANDER) this.state = STATE.INVESTIGATE;
    if (this.hp <= 0) { this.state = STATE.DYING; this._dyingT = 0; this.isThreat = false; }
  }

  dispose() {
    this.scene.remove(this.root);
    this.root.traverse(o => { if (o.geometry) o.geometry.dispose?.(); });
  }
}
