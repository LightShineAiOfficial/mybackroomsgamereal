/* =====================================================================
 * EntityManager.js — Spawns, updates, and culls the Bacteria entities.
 *
 * Spawns them OUT of view in the fog at the edge of the loaded world, caps
 * the live count per level, and despawns any that wander too far so the
 * infinite world never accumulates monsters. Also the central place that
 * answers "where's the nearest threat?" for the player, audio, companion.
 * ===================================================================== */

import * as THREE from 'three';
import { CFG } from '../config.js';
import { BacteriaEntity } from './BacteriaEntity.js';

export class EntityManager {
  constructor(scene) {
    this.scene = scene;
    this.entities = [];
    this.spawnTimer = 2.0;
    this.level = null;
  }

  setLevel(level) {
    for (const e of this.entities) e.dispose();
    this.entities.length = 0;
    this.level = level;
    this.spawnTimer = 4.0; // grace period after arriving
  }

  update(dt, game) {
    // ---- spawning ----
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      this.spawnTimer = 3 + Math.random() * 4;
      const alive = this.entities.filter(e => e.alive).length;
      if (alive < this.level.threat.maxAlive && Math.random() < this.level.threat.spawnChance * 6 * dt + this.level.threat.spawnChance) {
        this._trySpawn(game);
      }
    }

    // ---- update + cull ----
    const px = game.player.position.x, pz = game.player.position.z;
    for (const e of this.entities) {
      if (!e.alive) continue;
      e.update(dt, game);
      // Despawn anything that drifts beyond the streamed region.
      const d = Math.hypot(e.position.x - px, e.position.z - pz);
      if (d > CFG.chunkSize * (CFG.viewRadiusChunks + 1)) { e.dispose(); e.alive = false; }
    }
    this.entities = this.entities.filter(e => e.alive);
  }

  _trySpawn(game) {
    const sp = game.chunkManager.spawnPointAwayFrom(game.player.position, 14, null);
    if (!sp) return;
    const e = new BacteriaEntity(this.scene, sp);
    this.entities.push(e);
    // Distant warning vocalization so the player feels it arrive.
    game.audio.playMonsterVocal(game.audio.panFor(sp, game.player), 0.5);
  }

  /** Make nearby entities investigate a loud event (gunfire, scream…). */
  alertNoise(worldPos, radius) {
    for (const e of this.entities) {
      if (!e.alive) continue;
      if (Math.hypot(e.position.x - worldPos.x, e.position.z - worldPos.z) < radius) {
        e.lastKnownPlayer = new THREE.Vector3(worldPos.x, 1.6, worldPos.z);
        if (e.state === 'wander') e.state = 'investigate';
      }
    }
  }

  nearestThreatDistance(pos) {
    let best = Infinity;
    for (const e of this.entities) {
      if (!e.alive || !e.isThreat) continue;
      best = Math.min(best, Math.hypot(e.position.x - pos.x, e.position.z - pos.z));
    }
    return best;
  }

  /** Threats within radius of a point, nearest first (companion targeting). */
  threatsInRadius(pos, radius) {
    const out = [];
    for (const e of this.entities) {
      if (!e.alive || !e.isThreat) continue;
      const d = Math.hypot(e.position.x - pos.x, e.position.z - pos.z);
      if (d <= radius) out.push({ entity: e, dist: d });
    }
    out.sort((a, b) => a.dist - b.dist);
    return out;
  }

  count() { return this.entities.filter(e => e.alive && e.isThreat).length; }
}
