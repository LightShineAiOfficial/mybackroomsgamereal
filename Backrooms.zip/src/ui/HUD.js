/* =====================================================================
 * HUD.js — Thin controller over the DOM overlays declared in index.html.
 *
 * Keeps all querySelector noise in one place: vitals bars, level/objective,
 * companion status, transient subtitles, the interaction prompt, the
 * companion dialogue panel, and the recorder-log reader.
 * ===================================================================== */

export class HUD {
  constructor() {
    this.$ = (id) => document.getElementById(id);
    this.hud = this.$('hud');
    this.healthFill = this.$('health-fill');
    this.staminaFill = this.$('stamina-fill');
    this.sanityFill = this.$('sanity-fill');
    this.levelName = this.$('level-name');
    this.objective = this.$('objective');
    this.compStatus = this.$('companion-status');
    this.compAction = this.$('companion-action');
    this.ammoEl = this.$('ammo');
    this.ammoMag = this.$('ammo-mag');
    this.ammoMax = this.$('ammo-max');
    this.subtitles = this.$('subtitles');
    this.interact = this.$('interact-prompt');
    this.damage = this.$('damage-flash');
    this.proxRed = this.$('proximity-red');

    this.dialogue = this.$('dialogue');
    this.dialogueLog = this.$('dialogue-log');
    this.dialogueQuick = this.$('dialogue-quick');
    this.dialogueForm = this.$('dialogue-form');
    this.dialogueInput = this.$('dialogue-input');

    this.logReader = this.$('log-reader');
  }

  show() { this.hud.classList.remove('hidden'); }
  hide() { this.hud.classList.add('hidden'); }

  setLevel(level) {
    this.levelName.textContent = level.name;
    this.objective.textContent = 'Objective: ' + level.objective;
  }

  setVitals(h, s, san) {
    this.healthFill.style.width = Math.max(0, h) + '%';
    this.staminaFill.style.width = Math.max(0, s) + '%';
    this.sanityFill.style.width = Math.max(0, san) + '%';
    // Sanity tints the whole frame as it collapses.
    document.getElementById('vignette').style.opacity = (san < 50) ? (1 + (50 - san) / 60).toFixed(2) : '1';
  }

  setAmmo(mag, max, reloading) {
    this.ammoMag.textContent = reloading ? '··' : mag;
    this.ammoMax.textContent = max;
    this.ammoEl.classList.toggle('reloading', !!reloading);
    this.ammoEl.classList.toggle('empty', !reloading && mag <= 0);
  }

  setComms(statusText, subText) {
    this.compStatus.textContent = statusText;
    if (subText !== undefined) this.compAction.textContent = subText;
  }

  /** red 0..1 — how much the screen bleeds red from a nearby entity. */
  setProximity(red) {
    this.proxRed.style.opacity = red.toFixed(3);
    this.proxRed.classList.toggle('pulse', red > 0.55);
  }

  showInteract(text) {
    if (text) { this.interact.textContent = text; this.interact.classList.remove('hidden'); }
    else this.interact.classList.add('hidden');
  }

  damageFlash() {
    this.damage.style.opacity = '1';
    setTimeout(() => { this.damage.style.opacity = '0'; }, 120);
  }

  /** Transient subtitle line. speaker may be '' for ambient text. */
  subtitle(speaker, text, ms = 5000) {
    const line = document.createElement('div');
    line.className = 'line';
    line.innerHTML = (speaker ? `<span class="speaker">${speaker}:</span> ` : '') + this._escape(text);
    this.subtitles.appendChild(line);
    requestAnimationFrame(() => line.classList.add('show'));
    setTimeout(() => {
      line.classList.remove('show');
      setTimeout(() => line.remove(), 500);
    }, ms);
  }

  // ---- Dialogue panel ----
  openDialogue() {
    this.dialogue.classList.remove('hidden');
    setTimeout(() => this.dialogueInput.focus(), 30);
  }
  closeDialogue() {
    this.dialogue.classList.add('hidden');
    this.dialogueInput.blur();
  }
  isDialogueOpen() { return !this.dialogue.classList.contains('hidden'); }

  addMessage(who, text) {
    const m = document.createElement('div');
    m.className = 'msg ' + who; // 'you' | 'unit' | 'sys'
    const label = who === 'you' ? 'YOU' : who === 'unit' ? 'UNIT-7' : 'SYS';
    m.innerHTML = `<div class="who">${label}</div><div class="body">${this._escape(text)}</div>`;
    this.dialogueLog.appendChild(m);
    this.dialogueLog.scrollTop = this.dialogueLog.scrollHeight;
    return m.querySelector('.body');
  }

  addTyping() {
    const body = this.addMessage('unit', '');
    body.classList.add('typing');
    return body;
  }

  setQuickReplies(replies, onPick) {
    this.dialogueQuick.innerHTML = '';
    for (const r of replies) {
      const b = document.createElement('button');
      b.textContent = r;
      b.onclick = () => onPick(r);
      this.dialogueQuick.appendChild(b);
    }
  }

  // ---- Recorder-log reader ----
  openLog(title, body) {
    this.$('log-reader-title').textContent = title;
    this.$('log-reader-body').textContent = body;
    this.logReader.classList.remove('hidden');
  }
  closeLog() { this.logReader.classList.add('hidden'); }
  isLogOpen() { return !this.logReader.classList.contains('hidden'); }

  _escape(s) {
    return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }
}
