/* =====================================================================
 * AudioManager.js — 100% procedural Web Audio (no sound files).
 *
 *  • A low continuous drone + fluorescent buzz = the inescapable "hum".
 *  • Monster vocalizations: detuned formant clusters + noise, panned by
 *    where the creature is relative to your head. Genuinely unpleasant.
 *  • Dynamic heartbeat (faster as threats close in) and a tinnitus whine
 *    that rises as SANITY falls → psychological pressure, not just visuals.
 *
 * Must be init()'d from a user gesture (the Begin button) or browsers will
 * keep the AudioContext suspended.
 * ===================================================================== */

import * as THREE from 'three';

export class AudioManager {
  constructor() {
    this.ctx = null;
    this.ready = false;
    this.master = null;
    this._noiseBuf = null;
    this._beatTimer = 0;
    this._tinnitus = null;
  }

  init() {
    if (this.ready) { this.ctx.resume?.(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.6;
    this.master.connect(this.ctx.destination);

    // Pre-render 2s of white noise we can reuse everywhere.
    const len = this.ctx.sampleRate * 2;
    this._noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this._noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

    this.ready = true;
  }

  setMasterVolume(v) { if (this.master) this.master.gain.value = v; }

  // ---- helpers --------------------------------------------------------
  _noise() { const s = this.ctx.createBufferSource(); s.buffer = this._noiseBuf; s.loop = true; return s; }
  _env(node, peak, attack, decay, when = 0) {
    const t = this.ctx.currentTime + when;
    node.gain.cancelScheduledValues(t);
    node.gain.setValueAtTime(0.0001, t);
    node.gain.exponentialRampToValueAtTime(Math.max(0.0001, peak), t + attack);
    node.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
  }

  /** Stereo pan [-1,1] for a world position relative to the player's facing. */
  panFor(worldPos, player) {
    if (!player) return 0;
    const to = new THREE.Vector3().subVectors(worldPos, player.eyePosition);
    const right = new THREE.Vector3(Math.cos(player.yaw), 0, -Math.sin(player.yaw));
    const d = to.normalize().dot(right);
    return THREE.MathUtils.clamp(d, -1, 1);
  }

  // ---- ambient bed (per level) ---------------------------------------
  startAmbience(level) {
    if (!this.ready) return;
    this.stopAmbience();
    const a = level.atmosphere;
    const g = this.ctx.createGain();
    g.gain.value = a.ambientLevel ?? 0.18;
    g.connect(this.master);

    // Sub drone.
    const o1 = this.ctx.createOscillator(); o1.type = 'sawtooth'; o1.frequency.value = a.hum / 2;
    const o2 = this.ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = a.hum;
    const lp = this.ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 220;
    o1.connect(lp); o2.connect(lp); lp.connect(g);

    // Airy room tone (filtered noise).
    const n = this._noise();
    const bp = this.ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 600; bp.Q.value = 0.6;
    const ng = this.ctx.createGain(); ng.gain.value = 0.05;
    n.connect(bp); bp.connect(ng); ng.connect(g);

    o1.start(); o2.start(); n.start();
    this._ambience = { g, nodes: [o1, o2, n] };

    // Tinnitus oscillator (silent until sanity drops).
    const to = this.ctx.createOscillator(); to.type = 'sine'; to.frequency.value = 8200;
    const tg = this.ctx.createGain(); tg.gain.value = 0.0;
    to.connect(tg); tg.connect(this.master); to.start();
    this._tinnitus = tg;
  }
  stopAmbience() {
    this._ambience?.nodes.forEach(n => { try { n.stop(); } catch {} });
    this._ambience = null;
    if (this._tinnitus) { try { this._tinnitus.disconnect(); } catch {} this._tinnitus = null; }
  }

  // ---- dynamic per-frame layer ---------------------------------------
  update(dt, game) {
    if (!this.ready || !game.player) return;
    const p = game.player;

    // Tinnitus rises as sanity falls.
    if (this._tinnitus) {
      const target = p.sanity < 45 ? (45 - p.sanity) / 45 * 0.05 : 0;
      const cur = this._tinnitus.gain.value;
      this._tinnitus.gain.value = cur + (target - cur) * Math.min(1, dt * 3);
    }

    // Heartbeat — rate scales with nearest-threat proximity.
    const td = game.entityManager?.nearestThreatDistance(p.eyePosition) ?? Infinity;
    if (td < 16 || p.health < 35) {
      const closeness = Math.max(0, 1 - td / 16);
      const rate = 0.45 - closeness * 0.30 - (p.health < 35 ? 0.1 : 0); // seconds per beat
      this._beatTimer -= dt;
      if (this._beatTimer <= 0) { this._heartbeat(0.4 + closeness * 0.6); this._beatTimer = Math.max(0.28, rate); }
    }

    // Breathing/whisper layer when something is very close (and you can't
    // always see it). Panned toward the nearest threat for directional dread.
    this._breathTimer = (this._breathTimer || 0) - dt;
    if (td < 9 && this._breathTimer <= 0) {
      const t = game.entityManager?.threatsInRadius(p.eyePosition, 9)?.[0];
      const pan = t ? this.panFor(t.entity.position, p) : 0;
      this.playBreath(pan);
      this._breathTimer = 1.4 + Math.random() * 1.2;
    }
  }

  _heartbeat(vol) {
    if (!this.ready) return;
    const o = this.ctx.createOscillator(); o.type = 'sine'; o.frequency.value = 55;
    const g = this.ctx.createGain(); g.connect(this.master); o.connect(g);
    this._env(g, vol * 0.5, 0.01, 0.18);
    o.start(); o.stop(this.ctx.currentTime + 0.25);
  }

  // ---- one-shots ------------------------------------------------------
  playMonsterVocal(pan = 0, intensity = 1) {
    if (!this.ready) return;
    const out = this.ctx.createGain(); out.gain.value = 1;
    const panner = this.ctx.createStereoPanner(); panner.pan.value = pan;
    out.connect(panner); panner.connect(this.master);

    // Detuned formant cluster = inhuman "voice".
    const base = 90 + Math.random() * 60;
    for (let i = 0; i < 4; i++) {
      const o = this.ctx.createOscillator();
      o.type = i % 2 ? 'sawtooth' : 'square';
      o.frequency.value = base * (1 + i * 0.5) + (Math.random() - 0.5) * 30;
      const g = this.ctx.createGain();
      o.connect(g); g.connect(out);
      this._env(g, 0.12 * intensity, 0.03, 0.5 + Math.random() * 0.4);
      o.frequency.exponentialRampToValueAtTime(o.frequency.value * (0.6 + Math.random() * 0.6), this.ctx.currentTime + 0.5);
      o.start(); o.stop(this.ctx.currentTime + 1.1);
    }
    // Wet noise rasp on top.
    const n = this._noise();
    const bp = this.ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1200; bp.Q.value = 2;
    const ng = this.ctx.createGain(); n.connect(bp); bp.connect(ng); ng.connect(out);
    this._env(ng, 0.10 * intensity, 0.02, 0.4);
    n.start(); n.stop(this.ctx.currentTime + 0.6);
  }

  playGunshot(pan = 0) {
    if (!this.ready) return;
    const panner = this.ctx.createStereoPanner(); panner.pan.value = pan; panner.connect(this.master);
    const n = this._noise();
    const hp = this.ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 500;
    const g = this.ctx.createGain(); n.connect(hp); hp.connect(g); g.connect(panner);
    this._env(g, 0.5, 0.001, 0.12);
    n.start(); n.stop(this.ctx.currentTime + 0.15);
    // Low thump.
    const o = this.ctx.createOscillator(); o.type = 'sine'; o.frequency.value = 120;
    const g2 = this.ctx.createGain(); o.connect(g2); g2.connect(panner);
    this._env(g2, 0.35, 0.001, 0.1); o.frequency.exponentialRampToValueAtTime(40, this.ctx.currentTime + 0.1);
    o.start(); o.stop(this.ctx.currentTime + 0.12);
  }

  playStinger() {
    if (!this.ready) return;
    const o = this.ctx.createOscillator(); o.type = 'sawtooth';
    const g = this.ctx.createGain(); o.connect(g); g.connect(this.master);
    o.frequency.setValueAtTime(1600, this.ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(120, this.ctx.currentTime + 0.6);
    this._env(g, 0.5, 0.005, 0.7);
    o.start(); o.stop(this.ctx.currentTime + 0.8);
    this.playMonsterVocal(0, 1.4);
  }

  playPickup() {
    if (!this.ready) return;
    const o = this.ctx.createOscillator(); o.type = 'square'; o.frequency.value = 440;
    const g = this.ctx.createGain(); o.connect(g); g.connect(this.master);
    this._env(g, 0.12, 0.005, 0.12);
    o.frequency.setValueAtTime(440, this.ctx.currentTime);
    o.frequency.setValueAtTime(660, this.ctx.currentTime + 0.06);
    o.start(); o.stop(this.ctx.currentTime + 0.18);
  }

  playFootstep(vol = 0.1) {
    if (!this.ready) return;
    const n = this._noise();
    const lp = this.ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900;
    const g = this.ctx.createGain(); n.connect(lp); lp.connect(g); g.connect(this.master);
    this._env(g, vol, 0.005, 0.08);
    n.start(); n.stop(this.ctx.currentTime + 0.1);
  }

  // ---- NEW: player weapon + reactions --------------------------------
  /** The player's own gun: a sharp crack with a punchy body + tail. */
  playPlayerShot() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    // Crack (high noise transient).
    const n = this._noise();
    const hp = this.ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 1100;
    const g = this.ctx.createGain(); n.connect(hp); hp.connect(g); g.connect(this.master);
    this._env(g, 0.6, 0.0008, 0.09);
    n.start(); n.stop(t + 0.12);
    // Body thump.
    const o = this.ctx.createOscillator(); o.type = 'triangle'; o.frequency.setValueAtTime(180, t);
    o.frequency.exponentialRampToValueAtTime(50, t + 0.12);
    const g2 = this.ctx.createGain(); o.connect(g2); g2.connect(this.master);
    this._env(g2, 0.5, 0.001, 0.14);
    o.start(); o.stop(t + 0.16);
    // Reverb-ish tail (decaying band-passed noise).
    const n2 = this._noise();
    const bp = this.ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 800; bp.Q.value = 0.7;
    const g3 = this.ctx.createGain(); n2.connect(bp); bp.connect(g3); g3.connect(this.master);
    this._env(g3, 0.12, 0.01, 0.5);
    n2.start(); n2.stop(t + 0.6);
  }

  playReload() {
    if (!this.ready) return;
    // Two mechanical clacks: mag out, mag in.
    const clack = (when, freq) => {
      const o = this.ctx.createOscillator(); o.type = 'square'; o.frequency.value = freq;
      const g = this.ctx.createGain(); o.connect(g); g.connect(this.master);
      this._env(g, 0.18, 0.001, 0.05, when);
      o.start(this.ctx.currentTime + when); o.stop(this.ctx.currentTime + when + 0.08);
      const n = this._noise();
      const hp = this.ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 2000;
      const gn = this.ctx.createGain(); n.connect(hp); hp.connect(gn); gn.connect(this.master);
      this._env(gn, 0.12, 0.001, 0.04, when);
      n.start(this.ctx.currentTime + when); n.stop(this.ctx.currentTime + when + 0.06);
    };
    clack(0, 220); clack(0.18, 320); clack(0.9, 280);
  }

  playEmptyClick() {
    if (!this.ready) return;
    const o = this.ctx.createOscillator(); o.type = 'square'; o.frequency.value = 900;
    const g = this.ctx.createGain(); o.connect(g); g.connect(this.master);
    this._env(g, 0.08, 0.001, 0.03);
    o.start(); o.stop(this.ctx.currentTime + 0.05);
  }

  playHurt() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    // Distorted exhale: low sawtooth + noise burst.
    const o = this.ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(180, t);
    o.frequency.exponentialRampToValueAtTime(90, t + 0.25);
    const g = this.ctx.createGain(); o.connect(g); g.connect(this.master);
    this._env(g, 0.22, 0.005, 0.28);
    o.start(); o.stop(t + 0.35);
    const n = this._noise();
    const bp = this.ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 500; bp.Q.value = 1;
    const gn = this.ctx.createGain(); n.connect(bp); bp.connect(gn); gn.connect(this.master);
    this._env(gn, 0.15, 0.005, 0.22);
    n.start(); n.stop(t + 0.3);
  }

  /** Descent whoosh: downward pitch sweep + sub drop = falling through reality. */
  playDescend() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator(); o.type = 'sawtooth';
    o.frequency.setValueAtTime(900, t); o.frequency.exponentialRampToValueAtTime(40, t + 1.6);
    const lp = this.ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1200;
    const g = this.ctx.createGain(); o.connect(lp); lp.connect(g); g.connect(this.master);
    this._env(g, 0.35, 0.05, 1.6);
    o.start(); o.stop(t + 1.8);
    const n = this._noise();
    const bp = this.ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.setValueAtTime(1400, t);
    bp.frequency.exponentialRampToValueAtTime(120, t + 1.6);
    const gn = this.ctx.createGain(); n.connect(bp); bp.connect(gn); gn.connect(this.master);
    this._env(gn, 0.25, 0.05, 1.6);
    n.start(); n.stop(t + 1.8);
  }

  /** Big jumpscare hit — used when an entity locks on at close range. */
  playJumpscare(pan = 0) {
    if (!this.ready) return;
    const panner = this.ctx.createStereoPanner(); panner.pan.value = pan; panner.connect(this.master);
    const o = this.ctx.createOscillator(); o.type = 'sawtooth';
    o.frequency.setValueAtTime(2000, this.ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(80, this.ctx.currentTime + 0.5);
    const g = this.ctx.createGain(); o.connect(g); g.connect(panner);
    this._env(g, 0.7, 0.002, 0.6);
    o.start(); o.stop(this.ctx.currentTime + 0.7);
    this.playMonsterVocal(pan, 1.8);
  }

  /** Wet, panned breath/whisper — layered in when something is very close. */
  playBreath(pan = 0) {
    if (!this.ready) return;
    const panner = this.ctx.createStereoPanner(); panner.pan.value = pan; panner.connect(this.master);
    const n = this._noise();
    const bp = this.ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 700 + Math.random() * 400; bp.Q.value = 3;
    const g = this.ctx.createGain(); n.connect(bp); bp.connect(g); g.connect(panner);
    this._env(g, 0.16, 0.12, 0.5);
    n.start(); n.stop(this.ctx.currentTime + 0.7);
  }
}
