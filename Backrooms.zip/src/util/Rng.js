/* =====================================================================
 * Rng.js — Deterministic, seedable randomness.
 *
 * WHY DETERMINISM MATTERS
 * -----------------------
 * The world is infinite and we aggressively DELETE chunks the moment the
 * player can't see them (see ChunkManager). When the player turns around
 * and a chunk must be rebuilt, it MUST regenerate byte-for-byte identical
 * geometry — otherwise walls would silently move and the player could be
 * trapped inside a freshly spawned wall.
 *
 * We achieve this by deriving every chunk's RNG purely from its integer
 * (cx, cz) coordinates + the level seed. No global mutable state leaks in.
 * ===================================================================== */

// 32-bit integer hash (xmur3-ish) → produces a well-mixed seed integer.
export function hash2i(x, y, seed = 0) {
  let h = 2166136261 ^ seed;
  h = Math.imul(h ^ x, 16777619);
  h = Math.imul(h ^ y, 16777619);
  h ^= h >>> 13; h = Math.imul(h, 0x5bd1e995);
  h ^= h >>> 15;
  return h >>> 0;
}

// mulberry32 PRNG — tiny, fast, good enough for level layout.
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * A small ergonomic wrapper around a seeded stream.
 */
export class Rng {
  constructor(seed) { this.next = mulberry32(seed >>> 0); }
  /** float in [min,max) */
  range(min, max) { return min + (max - min) * this.next(); }
  /** int in [min,max] inclusive */
  int(min, max) { return Math.floor(this.range(min, max + 1)); }
  /** true with probability p */
  chance(p) { return this.next() < p; }
  /** pick a random element */
  pick(arr) { return arr[Math.floor(this.next() * arr.length)]; }

  /** Build a deterministic Rng for a specific chunk of a specific level. */
  static forChunk(cx, cz, levelSeed) {
    return new Rng(hash2i(cx, cz, levelSeed));
  }
}

// Cheap value-noise in [0,1] for smoothly varying things (light flicker bias,
// damp-stain placement, etc.). Deterministic per (x,z,seed).
export function valueNoise2(x, z, seed = 0) {
  const xi = Math.floor(x), zi = Math.floor(z);
  const xf = x - xi, zf = z - zi;
  const lerp = (a, b, t) => a + (b - a) * t;
  const fade = (t) => t * t * (3 - 2 * t);
  const r = (ix, iz) => (hash2i(ix, iz, seed) % 1000) / 1000;
  const x1 = lerp(r(xi, zi), r(xi + 1, zi), fade(xf));
  const x2 = lerp(r(xi, zi + 1), r(xi + 1, zi + 1), fade(xf));
  return lerp(x1, x2, fade(zf));
}

export const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
export const lerp = (a, b, t) => a + (b - a) * t;
