/* =====================================================================
 * ChunkManager.js — INFINITE procedural world + aggressive streaming.
 *
 * REQUIREMENT #1 (infinite generation + chunk cycling) lives here.
 *
 * How "infinite" works
 * --------------------
 * The level is an unbounded grid of CELLS. Walls live on the edges between
 * cells, and whether an edge is a wall is decided purely by hashing that
 * edge's GLOBAL integer coordinates (see Rng). Because the hash is global,
 * two neighbouring chunks always agree on the wall they share → seamless.
 *
 * How "delete everything you can't see" works
 * --------------------------------------------
 * Each frame we compute the set of chunks we WANT loaded: a radius around
 * the player PLUS a forward bias in the look direction (the player streams
 * the world ahead of where they're walking/looking). Any loaded chunk not
 * in that set is disposed *immediately* (geometry + buffers freed). When the
 * player turns back, the chunk is rebuilt byte-identical from its seed.
 *
 * NOTE on "pure frustum / POV-only deletion": deleting strictly what's off
 * screen makes the world pop violently when you spin around and breaks
 * collision behind you. So we use distance + forward-bias culling (the
 * industry-standard approach) which satisfies the same goal — keep the
 * working set tiny for infinite scale — without the artefacts. GPU frustum
 * culling (Three's default) still skips off-screen draw calls on top of it.
 * ===================================================================== */

import * as THREE from 'three';
import { CFG } from '../config.js';
import { Rng, hash2i, valueNoise2 } from '../util/Rng.js';
import { makeWallpaper, makeCarpet, makeCeiling, makeLightPanel } from './Textures.js';

// Deterministic hash salts so different feature layers don't correlate.
const SALT = { WALL_V: 11, WALL_H: 23, PILLAR: 31, ROOM: 41, LIGHT: 53, MOIST: 61, LOG: 71 };

// ---------------------------------------------------------------------
// Tiny merged-box geometry builder: lets a whole chunk's walls live in a
// single draw call instead of hundreds of meshes.
// ---------------------------------------------------------------------
class BoxBatch {
  constructor() { this.pos = []; this.norm = []; this.uv = []; this.idx = []; this.n = 0; }
  empty() { return this.n === 0; }

  addBox(cx, cy, cz, hx, hy, hz, s = 0.5) {
    const x0 = cx - hx, x1 = cx + hx, y0 = cy - hy, y1 = cy + hy, z0 = cz - hz, z1 = cz + hz;
    const face = (v, nx, ny, nz, uv) => {
      const b = this.n;
      for (let i = 0; i < 4; i++) {
        this.pos.push(v[i][0], v[i][1], v[i][2]);
        this.norm.push(nx, ny, nz);
        this.uv.push(uv[i][0], uv[i][1]);
      }
      this.idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
      this.n += 4;
    };
    face([[x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1]], 1,0,0, [[z1*s,y0*s],[z0*s,y0*s],[z0*s,y1*s],[z1*s,y1*s]]);
    face([[x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0]], -1,0,0, [[z0*s,y0*s],[z1*s,y0*s],[z1*s,y1*s],[z0*s,y1*s]]);
    face([[x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0]], 0,1,0, [[x0*s,z1*s],[x1*s,z1*s],[x1*s,z0*s],[x0*s,z0*s]]);
    face([[x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1]], 0,-1,0, [[x0*s,z0*s],[x1*s,z0*s],[x1*s,z1*s],[x0*s,z1*s]]);
    face([[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]], 0,0,1, [[x0*s,y0*s],[x1*s,y0*s],[x1*s,y1*s],[x0*s,y1*s]]);
    face([[x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0]], 0,0,-1, [[x1*s,y0*s],[x0*s,y0*s],[x0*s,y1*s],[x1*s,y1*s]]);
  }

  toGeometry() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('normal',   new THREE.Float32BufferAttribute(this.norm, 3));
    g.setAttribute('uv',       new THREE.Float32BufferAttribute(this.uv, 2));
    g.setIndex(this.idx);
    g.computeBoundingSphere();
    return g;
  }
}

export class ChunkManager {
  constructor(scene) {
    this.scene = scene;
    this.chunks = new Map();      // "cx,cz" -> chunk record
    this.buildQueue = [];
    this.maxBuildsPerFrame = 2;
    this.exposure = 0.5;          // how lit the player currently is (0..1)
    this.level = null;
    this._mats = null;
    this._sharedGeom = null;
    this._lightPool = [];
  }

  key(cx, cz) { return cx + ',' + cz; }
  worldToChunk(x, z) {
    return { cx: Math.floor(x / CFG.chunkSize), cz: Math.floor(z / CFG.chunkSize) };
  }

  // ---- Level (re)configuration ---------------------------------------
  setLevel(level) {
    this._disposeAll();
    // Free the previous level's materials (textures are palette-cached & reused).
    if (this._mats) for (const m of Object.values(this._mats)) m.dispose?.();
    this.level = level;
    this.levelSeed = (CFG.worldSeed + (level.seedOffset | 0)) >>> 0;

    const p = level.palette;
    const wallpaper = makeWallpaper(p), carpet = makeCarpet(p),
          ceiling = makeCeiling(p), lamp = makeLightPanel(p);

    this._mats = {
      wall:  new THREE.MeshStandardMaterial({ map: wallpaper, roughness: 0.96, metalness: 0.0, side: THREE.DoubleSide, color: 0xffffff }),
      floor: new THREE.MeshStandardMaterial({ map: carpet,    roughness: 1.0,  metalness: 0.0 }),
      ceil:  new THREE.MeshStandardMaterial({ map: ceiling,   roughness: 0.95, metalness: 0.0, side: THREE.DoubleSide }),
      panel: new THREE.MeshStandardMaterial({ map: lamp, emissive: new THREE.Color(p.light), emissiveMap: lamp, emissiveIntensity: 1.2, roughness: 0.4 }),
      log:   new THREE.MeshStandardMaterial({ color: 0x1a1a1a, emissive: 0x802000, emissiveIntensity: 0.6, roughness: 0.6 }),
      descent: new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.85 }),
      descentGlow: new THREE.MeshBasicMaterial({ color: p.light, transparent: true, opacity: 0.25, side: THREE.DoubleSide }),
    };

    // Shared floor / ceiling plane geometry (positioned per chunk).
    const repeat = CFG.chunkSize / 2;
    this._sharedGeom = {
      floor: this._plane(CFG.chunkSize, repeat, -Math.PI / 2),
      ceil:  this._plane(CFG.chunkSize, repeat,  Math.PI / 2),
    };

    // Constant-size pool of dynamic point lights that chase the nearest
    // fluorescent fixtures around the player → infinite lights, fixed cost.
    // Pool size is a perf knob (fewer lights = faster shading).
    for (let i = 0; i < CFG.lightPoolSize; i++) {
      const l = new THREE.PointLight(p.light, 0, 16, 1.6);
      this.scene.add(l);
      this._lightPool.push({ light: l, phase: Math.random() * 100 });
    }
  }

  _plane(size, repeat, rotX) {
    const g = new THREE.PlaneGeometry(size, size);
    g.rotateX(rotX);
    const uv = g.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * repeat, uv.getY(i) * repeat);
    uv.needsUpdate = true;
    return g;
  }

  // ---- Per-frame streaming -------------------------------------------
  update(playerPos, forwardFlat, dt) {
    const { cx, cz } = this.worldToChunk(playerPos.x, playerPos.z);
    const R = CFG.viewRadiusChunks;
    const want = new Set();

    // Circular radius around the player.
    for (let dz = -R; dz <= R; dz++)
      for (let dx = -R; dx <= R; dx++)
        if (dx * dx + dz * dz <= (R + 0.4) * (R + 0.4)) want.add(this.key(cx + dx, cz + dz));

    // Forward bias: stream extra chunks in the look direction.
    const fdx = Math.round(forwardFlat.x), fdz = Math.round(forwardFlat.z);
    for (let k = 1; k <= CFG.forwardBiasChunks; k++) {
      want.add(this.key(cx + fdx * (R + k), cz + fdz * (R + k)));
      want.add(this.key(cx + fdx * (R + k) + fdz, cz + fdz * (R + k) + fdx)); // small fan
      want.add(this.key(cx + fdx * (R + k) - fdz, cz + fdz * (R + k) - fdx));
    }

    // Unload anything we no longer want — ACTIVE DELETION.
    for (const k of [...this.chunks.keys()]) {
      if (!want.has(k)) this._unloadChunk(k);
    }

    // Queue missing chunks, nearest first.
    for (const k of want) {
      if (!this.chunks.has(k) && !this.buildQueue.includes(k)) this.buildQueue.push(k);
    }
    this.buildQueue.sort((a, b) => this._distToPlayer(a, cx, cz) - this._distToPlayer(b, cx, cz));
    for (let i = 0; i < this.maxBuildsPerFrame && this.buildQueue.length; i++) {
      this._buildChunk(this.buildQueue.shift());
    }

    this._updateLights(playerPos, dt);
  }

  /** Build the whole visible neighbourhood at once (used right after spawn). */
  primeAround(playerPos, forwardFlat) {
    const saved = this.maxBuildsPerFrame;
    this.maxBuildsPerFrame = 999;
    this.update(playerPos, forwardFlat, 0);
    // The first update only queued; drain the queue now.
    while (this.buildQueue.length) this._buildChunk(this.buildQueue.shift());
    this.maxBuildsPerFrame = saved;
  }

  _distToPlayer(key, cx, cz) {
    const [kx, kz] = key.split(',').map(Number);
    return (kx - cx) ** 2 + (kz - cz) ** 2;
  }

  // ---- Generation -----------------------------------------------------
  _wallV(gx, gz, density) { // vertical wall on the WEST edge of cell (gx,gz)
    if (this._spawnSafe(gx, gz) && this._spawnSafe(gx - 1, gz)) return false;
    return (hash2i(gx, gz, this.levelSeed + SALT.WALL_V) % 1000) / 1000 < density;
  }
  _wallH(gx, gz, density) { // horizontal wall on the SOUTH edge of cell (gx,gz)
    if (this._spawnSafe(gx, gz) && this._spawnSafe(gx, gz - 1)) return false;
    return (hash2i(gx, gz, this.levelSeed + SALT.WALL_H) % 1000) / 1000 < density;
  }
  _spawnSafe(gx, gz) { return Math.abs(gx) <= 1 && Math.abs(gz) <= 1; } // keep origin open

  _buildChunk(key) {
    if (this.chunks.has(key)) return;
    const [cx, cz] = key.split(',').map(Number);
    const cells = CFG.cellsPerChunk, cs = CFG.cellSize, h = CFG.wallHeight;
    const g = this.level.gen;
    const rng = Rng.forChunk(cx, cz, this.levelSeed);
    const isOpenRoom = rng.chance(g.openRoomChance);
    const density = isOpenRoom ? g.wallDensity * 0.15 : g.wallDensity;

    const group = new THREE.Group();
    const walls = new BoxBatch();
    const panels = new BoxBatch();
    const colliders = [];
    const fixtures = [];
    const interactables = [];
    const spawnPoints = [];

    const xStart = cx * cells, zStart = cz * cells;
    const t = 0.18; // wall half-thickness

    for (let lz = 0; lz < cells; lz++) {
      for (let lx = 0; lx < cells; lx++) {
        const gx = xStart + lx, gz = zStart + lz;
        const wx = gx * cs, wz = gz * cs;          // world coords of cell's SW corner

        // West edge (vertical wall) at x = wx, spanning z..z+cs
        if (this._wallV(gx, gz, density)) {
          walls.addBox(wx, h / 2, wz + cs / 2, t, h / 2, cs / 2);
          colliders.push({ minX: wx - t, maxX: wx + t, minZ: wz, maxZ: wz + cs });
        }
        // South edge (horizontal wall) at z = wz, spanning x..x+cs
        if (this._wallH(gx, gz, density)) {
          walls.addBox(wx + cs / 2, h / 2, wz, cs / 2, h / 2, t);
          colliders.push({ minX: wx, maxX: wx + cs, minZ: wz - t, maxZ: wz + t });
        }
        // Pillar at SW corner
        if ((hash2i(gx, gz, this.levelSeed + SALT.PILLAR) % 1000) / 1000 < g.pillarChance && !this._spawnSafe(gx, gz)) {
          walls.addBox(wx, h / 2, wz, 0.22, h / 2, 0.22);
          colliders.push({ minX: wx - 0.24, maxX: wx + 0.24, minZ: wz - 0.24, maxZ: wz + 0.24 });
        }

        // Ceiling fixture grid
        const cellCenterX = wx + cs / 2, cellCenterZ = wz + cs / 2;
        if ((gx % g.lightEveryCells === 0) && (gz % g.lightEveryCells === 0)) {
          panels.addBox(cellCenterX, h - 0.02, cellCenterZ, cs * 0.3, 0.02, cs * 0.3);
          fixtures.push(new THREE.Vector3(cellCenterX, h - 0.15, cellCenterZ));
        }

        spawnPoints.push(new THREE.Vector3(cellCenterX, 0, cellCenterZ));
      }
    }

    // ---- Floor + ceiling planes (shared geometry, positioned) ----
    const cwx = cx * CFG.chunkSize + CFG.chunkSize / 2;
    const cwz = cz * CFG.chunkSize + CFG.chunkSize / 2;
    const floor = new THREE.Mesh(this._sharedGeom.floor, this._mats.floor);
    floor.position.set(cwx, 0, cwz); group.add(floor);
    const ceil = new THREE.Mesh(this._sharedGeom.ceil, this._mats.ceil);
    ceil.position.set(cwx, h, cwz); group.add(ceil);

    // ---- Walls + panels (unique geometry per chunk) ----
    let wallGeom = null, panelGeom = null;
    if (!walls.empty()) {
      wallGeom = walls.toGeometry();
      group.add(new THREE.Mesh(wallGeom, this._mats.wall));
    }
    if (!panels.empty()) {
      panelGeom = panels.toGeometry();
      group.add(new THREE.Mesh(panelGeom, this._mats.panel));
    }

    // ---- Interactables: recorder logs + descent points ----
    const cRng = Rng.forChunk(cx, cz, this.levelSeed + 9999);
    if (cRng.chance(g.logChance)) {
      const sp = cRng.pick(spawnPoints);
      const logIndex = hash2i(cx, cz, this.levelSeed + SALT.LOG);
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.08, 0.12), this._mats.log);
      mesh.position.set(sp.x, 0.5, sp.z);
      group.add(mesh);
      interactables.push({ type: 'log', position: mesh.position.clone(), mesh, logIndex, used: false });
    }
    if (cRng.chance(g.moistChance) && !(cx === 0 && cz === 0)) {
      const sp = cRng.pick(spawnPoints);
      const disc = new THREE.Mesh(new THREE.CircleGeometry(cs * 0.4, 24), this._mats.descent);
      disc.rotation.x = -Math.PI / 2; disc.position.set(sp.x, 0.02, sp.z);
      const glow = new THREE.Mesh(new THREE.CircleGeometry(cs * 0.42, 24), this._mats.descentGlow);
      glow.rotation.x = -Math.PI / 2; glow.position.set(sp.x, 0.015, sp.z);
      group.add(disc); group.add(glow);
      interactables.push({ type: 'descent', position: disc.position.clone(), mesh: disc, used: false });
    }

    this.scene.add(group);
    this.chunks.set(key, { cx, cz, group, wallGeom, panelGeom, colliders, fixtures, interactables, spawnPoints });
  }

  _unloadChunk(key) {
    const c = this.chunks.get(key);
    if (!c) return;
    this.scene.remove(c.group);
    // Dispose ONLY per-chunk geometry; shared geom/materials persist.
    c.wallGeom?.dispose();
    c.panelGeom?.dispose();
    for (const it of c.interactables) it.mesh?.geometry?.dispose?.();
    c.group.traverse(o => { if (o.geometry && o.geometry !== this._sharedGeom.floor && o.geometry !== this._sharedGeom.ceil && o.geometry !== c.wallGeom && o.geometry !== c.panelGeom) o.geometry.dispose?.(); });
    this.chunks.delete(key);
  }

  // ---- Dynamic light pool + flicker ----------------------------------
  _updateLights(playerPos, dt) {
    const time = performance.now() / 1000;
    // PERF: only scan fixtures in the player's immediate chunk neighbourhood
    // instead of every loaded chunk (identical visual result, far less CPU).
    const { cx, cz } = this.worldToChunk(playerPos.x, playerPos.z);
    const cand = [];
    for (let dz = -2; dz <= 2; dz++)
      for (let dx = -2; dx <= 2; dx++) {
        const c = this.chunks.get(this.key(cx + dx, cz + dz));
        if (!c) continue;
        for (const f of c.fixtures) {
          const d2 = (f.x - playerPos.x) ** 2 + (f.z - playerPos.z) ** 2;
          if (d2 < 18 * 18) cand.push({ f, d2 });
        }
      }
    cand.sort((a, b) => a.d2 - b.d2);

    const flicker = this.level.atmosphere.flicker;
    let bestExposure = 0;
    for (let i = 0; i < this._lightPool.length; i++) {
      const slot = this._lightPool[i];
      const c = cand[i];
      if (!c) { slot.light.intensity = 0; continue; }
      slot.light.position.copy(c.f);
      // Per-fixture deterministic flicker via value noise + sine buzz.
      const n = valueNoise2(c.f.x * 0.7, c.f.z * 0.7 + time * (0.6 + flicker), 7);
      const dropout = n < flicker * 0.5 ? 0.05 : 1.0;     // occasional dead tube
      const buzz = 0.85 + 0.15 * Math.sin(time * 40 + slot.phase);
      slot.light.intensity = 20 * dropout * buzz;         // physical-units fluorescent
      slot.light.distance = 16;
      const inv = 1 - Math.min(1, c.d2 / (10 * 10));
      bestExposure = Math.max(bestExposure, inv * dropout);
    }
    this.exposure = bestExposure;
  }

  // ---- Queries used by player / entities / interaction ---------------
  collidersNear(x, z) {
    const { cx, cz } = this.worldToChunk(x, z);
    const out = [];
    for (let dz = -1; dz <= 1; dz++)
      for (let dx = -1; dx <= 1; dx++) {
        const c = this.chunks.get(this.key(cx + dx, cz + dz));
        if (c) for (const col of c.colliders) out.push(col);
      }
    return out;
  }

  /** Is the straight segment a→b unobstructed by walls? (sight / line-of-fire) */
  segmentClear(ax, az, bx, bz, step = 0.5) {
    const dx = bx - ax, dz = bz - az;
    const dist = Math.hypot(dx, dz);
    const n = Math.max(1, Math.ceil(dist / step));
    for (let i = 1; i < n; i++) {
      const t = i / n, px = ax + dx * t, pz = az + dz * t;
      for (const c of this.collidersNear(px, pz)) {
        if (px >= c.minX && px <= c.maxX && pz >= c.minZ && pz <= c.maxZ) return false;
      }
    }
    return true;
  }

  /** Nearest interactable (log/descent) to a point within `range`. */
  nearestInteractable(pos, range = 1.6) {
    let best = null, bestD = range * range;
    for (const c of this.chunks.values()) {
      for (const it of c.interactables) {
        if (it.used && it.type === 'log') continue;
        const d2 = (it.position.x - pos.x) ** 2 + (it.position.z - pos.z) ** 2;
        if (d2 < bestD) { bestD = d2; best = it; }
      }
    }
    return best;
  }

  /** Random loaded spawn point at least `minDist` from the player (for monsters). */
  spawnPointAwayFrom(pos, minDist, rng) {
    const pool = [];
    for (const c of this.chunks.values()) {
      for (const sp of c.spawnPoints) {
        const d = Math.hypot(sp.x - pos.x, sp.z - pos.z);
        if (d > minDist && d < CFG.fogFar) pool.push(sp);
      }
    }
    return pool.length ? pool[Math.floor((rng ? rng.next() : Math.random()) * pool.length)] : null;
  }

  _disposeAll() {
    for (const k of [...this.chunks.keys()]) this._unloadChunk(k);
    this.chunks.clear();
    this.buildQueue.length = 0;
    for (const s of this._lightPool) this.scene.remove(s.light);
    this._lightPool.length = 0;
    this._sharedGeom?.floor.dispose();
    this._sharedGeom?.ceil.dispose();
    this._sharedGeom = null;
  }
}
