/* =====================================================================
 * Textures.js — Procedurally painted canvas textures.
 *
 * Everything is generated at runtime (no image files to ship), then cached
 * per level palette. Gives the walls grime, the carpet fibre noise, and the
 * ceiling its stained acoustic-tile grid — the stuff that sells "liminal".
 * ===================================================================== */

import * as THREE from 'three';

const _cache = new Map();
const hex = (c) => '#' + c.toString(16).padStart(6, '0');

function canvas(size = 256) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  return c;
}
function finalize(canvasEl, repeat = 1) {
  const tex = new THREE.CanvasTexture(canvasEl);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.anisotropy = 4;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// Lay down fine multiplicative grain over the whole canvas.
function grain(ctx, size, intensity) {
  const img = ctx.getImageData(0, 0, size, size);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = 1 + (Math.random() - 0.5) * intensity;
    d[i] *= n; d[i + 1] *= n; d[i + 2] *= n;
  }
  ctx.putImageData(img, 0, 0);
}

// Soft irregular damp stain.
function stain(ctx, x, y, r, color, alpha) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, color);
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.globalAlpha = alpha;
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;
}

export function makeWallpaper(palette) {
  const k = 'wall' + palette.wall;
  if (_cache.has(k)) return _cache.get(k);
  const size = 256, c = canvas(size), ctx = c.getContext('2d');
  ctx.fillStyle = hex(palette.wall);
  ctx.fillRect(0, 0, size, size);

  // Faint vertical wallpaper stripes.
  ctx.fillStyle = hex(palette.wallAlt ?? palette.wall);
  for (let x = 0; x < size; x += 16) {
    ctx.globalAlpha = 0.10;
    ctx.fillRect(x, 0, 8, size);
  }
  ctx.globalAlpha = 1;

  // Grime running down from the top, random damp stains.
  for (let i = 0; i < 18; i++) {
    stain(ctx, Math.random() * size, Math.random() * size,
      8 + Math.random() * 26, 'rgba(40,30,10,1)', 0.06 + Math.random() * 0.08);
  }
  // Baseboard shadow at the very bottom.
  const grad = ctx.createLinearGradient(0, size - 28, 0, size);
  grad.addColorStop(0, 'rgba(0,0,0,0)');
  grad.addColorStop(1, 'rgba(0,0,0,0.35)');
  ctx.fillStyle = grad; ctx.fillRect(0, size - 28, size, 28);

  grain(ctx, size, 0.10);
  const tex = finalize(c, 1);
  _cache.set(k, tex);
  return tex;
}

export function makeCarpet(palette) {
  const k = 'floor' + palette.floor;
  if (_cache.has(k)) return _cache.get(k);
  const size = 256, c = canvas(size), ctx = c.getContext('2d');
  ctx.fillStyle = hex(palette.floor);
  ctx.fillRect(0, 0, size, size);
  // Dense fibre speckle.
  for (let i = 0; i < 9000; i++) {
    const x = Math.random() * size, y = Math.random() * size;
    const v = (Math.random() - 0.5) * 60;
    ctx.fillStyle = `rgba(${v < 0 ? 0 : 255},${v < 0 ? 0 : 255},${v < 0 ? 0 : 255},${Math.abs(v) / 255 * 0.4})`;
    ctx.fillRect(x, y, 1, 1);
  }
  for (let i = 0; i < 8; i++) {
    stain(ctx, Math.random() * size, Math.random() * size, 20 + Math.random() * 40, 'rgba(20,15,0,1)', 0.10);
  }
  grain(ctx, size, 0.14);
  const tex = finalize(c, 1);
  _cache.set(k, tex);
  return tex;
}

export function makeCeiling(palette) {
  const k = 'ceil' + palette.ceiling;
  if (_cache.has(k)) return _cache.get(k);
  const size = 256, c = canvas(size), ctx = c.getContext('2d');
  ctx.fillStyle = hex(palette.ceiling);
  ctx.fillRect(0, 0, size, size);
  // Acoustic-tile grid (2x2 tiles per texture tile).
  ctx.strokeStyle = 'rgba(0,0,0,0.30)';
  ctx.lineWidth = 3;
  for (let i = 0; i <= size; i += size / 2) {
    ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, size); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(size, i); ctx.stroke();
  }
  // Pinhole perforations + water stains.
  ctx.fillStyle = 'rgba(0,0,0,0.12)';
  for (let i = 0; i < 1200; i++) ctx.fillRect(Math.random() * size, Math.random() * size, 1, 1);
  for (let i = 0; i < 5; i++) stain(ctx, Math.random() * size, Math.random() * size, 18 + Math.random() * 30, 'rgba(70,55,20,1)', 0.18);
  grain(ctx, size, 0.08);
  const tex = finalize(c, 1);
  _cache.set(k, tex);
  return tex;
}

/** Bright fluorescent panel face (emissive). */
export function makeLightPanel(palette) {
  const k = 'lamp' + palette.light;
  if (_cache.has(k)) return _cache.get(k);
  const size = 128, c = canvas(size), ctx = c.getContext('2d');
  ctx.fillStyle = '#2a2a26'; ctx.fillRect(0, 0, size, size);     // frame
  const m = 10;
  const g = ctx.createLinearGradient(0, 0, 0, size);
  g.addColorStop(0, hex(palette.light));
  g.addColorStop(0.5, '#ffffff');
  g.addColorStop(1, hex(palette.light));
  ctx.fillStyle = g; ctx.fillRect(m, m, size - 2 * m, size - 2 * m);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  _cache.set(k, tex);
  return tex;
}

export function clearTextureCache() {
  for (const t of _cache.values()) t.dispose?.();
  _cache.clear();
}
