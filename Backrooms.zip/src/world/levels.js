/* =====================================================================
 * levels.js — Data-driven definitions for each Backrooms level.
 *
 * Each level is just a config object. ChunkManager reads `gen` to build
 * geometry; the Game reads palette/atmosphere; StoryManager reads `lore`.
 * Adding a new level = adding an entry here. The world is infinite WITHIN
 * each level; descending happens at procedurally placed "noclip" exits.
 * ===================================================================== */

export const LEVELS = [
  {
    id: 0,
    name: 'LEVEL 0 — THE LOBBY',
    objective: 'Survive the endless yellow. Find a moist carpet to noclip deeper.',
    seedOffset: 0,
    palette: {
      wall:    0xb3a14a,   // iconic mono-yellow wallpaper
      wallAlt: 0xa8923f,
      floor:   0x9c8a3c,   // damp mono-yellow carpet
      ceiling: 0xd9d2b0,   // stained acoustic tiles
      fog:     0xb6a448,
      light:   0xfff4cf,   // warm-sick fluorescent
      trim:    0x6f5f25,
    },
    atmosphere: { fogNear: 4, fogFar: 30, hum: 60, flicker: 0.18, ambientLevel: 0.22 },
    gen: {
      wallDensity: 0.40,    // probability a maze edge becomes a wall
      pillarChance: 0.10,
      openRoomChance: 0.14, // chance a chunk is a large open room
      lightEveryCells: 1,   // fluorescent fixture density
      moistChance: 0.05,    // damp carpet patches (descent points)
      logChance: 0.10,      // recorder-log spawn chance per chunk
    },
    threat: { spawnChance: 0.05, maxAlive: 2 },
    lore: 'almond water · the hum · 1.0 atmospheres',
  },

  {
    id: 1,
    name: 'LEVEL 1 — HABITABLE ZONE',
    objective: 'Vast grey warehouse. Watch the dark aisles. Keep UNIT-7 close.',
    seedOffset: 7919,
    palette: {
      wall:    0x8f8f86,
      wallAlt: 0x7d7d73,
      floor:   0x5c5c55,
      ceiling: 0x3a3a36,
      fog:     0x4a4a45,
      light:   0xcfd6e0,   // cold fluorescent
      trim:    0x2a2a26,
    },
    atmosphere: { fogNear: 5, fogFar: 38, hum: 48, flicker: 0.30, ambientLevel: 0.14 },
    gen: {
      wallDensity: 0.26, pillarChance: 0.18, openRoomChance: 0.30,
      lightEveryCells: 2, moistChance: 0.04, logChance: 0.12,
    },
    threat: { spawnChance: 0.10, maxAlive: 3 },
    lore: 'concrete · distant machinery · forklifts that never moved',
  },

  {
    id: 2,
    name: 'LEVEL 2 — PIPE DREAMS',
    objective: 'Heat, steam, and endless pipes. Something nests in the dark here.',
    seedOffset: 104729,
    palette: {
      wall:    0x4a443c,
      wallAlt: 0x3c372f,
      floor:   0x2e2a24,
      ceiling: 0x1c1a16,
      fog:     0x241f1a,
      light:   0xffbf7a,   // sodium / emergency
      trim:    0x14110d,
    },
    atmosphere: { fogNear: 3, fogFar: 24, hum: 90, flicker: 0.45, ambientLevel: 0.08 },
    gen: {
      wallDensity: 0.50, pillarChance: 0.30, openRoomChance: 0.06,
      lightEveryCells: 3, moistChance: 0.03, logChance: 0.14,
    },
    threat: { spawnChance: 0.16, maxAlive: 4 },
    lore: 'steam · dripping · the things in the pipes are awake',
  },
];

// ---------------------------------------------------------------------
// Normalize: a couple of palette literals above were intentionally written
// with placeholders to keep the table readable; coerce everything to ints
// and guarantee valid colors. (Defensive: never ship a NaN color.)
// ---------------------------------------------------------------------
function coerceColor(c, fallback) {
  return (typeof c === 'number' && Number.isFinite(c)) ? c : fallback;
}
for (const L of LEVELS) {
  L.palette.wall = coerceColor(L.palette.wall, 0xb3a14a);
  L.palette.fog  = coerceColor(L.palette.fog, L.palette.wall);
}

export function getLevel(id) {
  return LEVELS.find(l => l.id === id) || LEVELS[0];
}
export const MAX_LEVEL = LEVELS[LEVELS.length - 1].id;
