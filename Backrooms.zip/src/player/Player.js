/* =====================================================================
 * Player.js — First-person controller.
 *
 *  • Yaw/pitch mouse-look (camera is the player's eyes)
 *  • WASD + sprint + jump with gravity
 *  • Circle-vs-AABB collision against streamed wall colliders
 *  • Flashlight (toggleable spotlight) + faint personal point light
 *  • Head-bob for immersion
 *  • Vitals: health / stamina / sanity
 *  • Emits a "noise level" each frame that the Bacteria entities can hear
 * ===================================================================== */

import * as THREE from 'three';
import { CFG } from '../config.js';
import { clamp } from '../util/Rng.js';

export class Player {
  constructor(camera, scene) {
    this.camera = camera;
    this.scene = scene;

    // Feet position (camera sits CFG.playerHeight above this).
    this.position = new THREE.Vector3(0, 0, 0);
    this.velocityY = 0;
    this.onGround = true;

    this.yaw = 0;
    this.pitch = 0;

    // Vitals
    this.health = 100;
    this.stamina = 100;
    this.sanity = 100;
    this.alive = true;

    // Movement bookkeeping
    this._bobPhase = 0;
    this._bobAmount = 0;
    this.noiseLevel = 0;     // 0..1, consumed by EntityManager
    this.speed = 0;

    // ---- Weapon ----
    this.ammo = CFG.weapon.magSize;
    this.reloading = false;
    this._reloadT = 0;
    this._fireCd = 0;
    this._recoil = 0;        // current recoil kick (0..1)
    this._vmSwayX = 0; this._vmSwayY = 0;

    this._buildFlashlight();
    this._buildViewmodel();
  }

  // First-person Async hazmat viewmodel: gloved arms + a pistol, rendered in
  // a SEPARATE overlay scene so world walls never clip through the gun.
  _buildViewmodel() {
    this.viewScene = new THREE.Scene();
    this.viewCamera = new THREE.PerspectiveCamera(58, innerWidth / innerHeight, 0.01, 10);
    // Self-contained lighting so the gun reads regardless of world darkness.
    this.viewScene.add(new THREE.AmbientLight(0xffffff, 1.1));
    const dl = new THREE.DirectionalLight(0xfff0e0, 1.6); dl.position.set(0.4, 1, 0.6);
    this.viewScene.add(dl);

    this.viewModel = new THREE.Group();
    this.viewScene.add(this.viewModel);

    const hazmat = new THREE.MeshStandardMaterial({ color: 0xd8742a, roughness: 0.7, metalness: 0.05 }); // ASYNC orange
    const cuff   = new THREE.MeshStandardMaterial({ color: 0x202020, roughness: 0.6 });
    const metal  = new THREE.MeshStandardMaterial({ color: 0x16181b, roughness: 0.45, metalness: 0.7 });
    const accent = new THREE.MeshStandardMaterial({ color: 0x2b2b2b, roughness: 0.5, metalness: 0.4 });

    // --- right gloved forearm reaching to the grip ---
    const armR = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.34, 4, 8), hazmat);
    armR.position.set(0.13, -0.28, -0.30); armR.rotation.set(1.15, 0.0, 0.15);
    this.viewModel.add(armR);
    const cuffR = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.07, 0.06, 10), cuff);
    cuffR.position.set(0.16, -0.40, -0.18); cuffR.rotation.x = 1.15;
    this.viewModel.add(cuffR);

    // --- left gloved forearm bracing under the barrel ---
    const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.30, 4, 8), hazmat);
    armL.position.set(-0.10, -0.26, -0.34); armL.rotation.set(1.2, 0.0, -0.35);
    this.viewModel.add(armL);

    // --- pistol ---
    const gun = new THREE.Group();
    gun.position.set(0.05, -0.20, -0.42);
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.10, 0.26), metal);
    gun.add(body);
    const slide = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.05, 0.30), accent);
    slide.position.set(0, 0.06, -0.01); gun.add(slide);
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.10, 8), metal);
    barrel.rotation.x = Math.PI / 2; barrel.position.set(0, 0.045, -0.18); gun.add(barrel);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.13, 0.07), accent);
    grip.position.set(0, -0.09, 0.07); grip.rotation.x = -0.25; gun.add(grip);
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.10, 0.05), metal);
    mag.position.set(0, -0.14, 0.06); gun.add(mag);
    this.gun = gun;
    this.viewModel.add(gun);

    // Muzzle flash (light + additive sprite-ish quad) at the barrel tip.
    this._muzzleTip = new THREE.Vector3(0.05, -0.155, -0.66);
    this._muzzleLight = new THREE.PointLight(0xffd27a, 0, 3, 2);
    this._muzzleLight.position.copy(this._muzzleTip);
    this.viewScene.add(this._muzzleLight);
    this._flash = new THREE.Mesh(
      new THREE.PlaneGeometry(0.22, 0.22),
      new THREE.MeshBasicMaterial({ color: 0xffe6a8, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false })
    );
    this._flash.position.copy(this._muzzleTip);
    this.viewScene.add(this._flash);

    this._vmBasePos = this.viewModel.position.clone();
  }

  _buildFlashlight() {
    // Spotlight = the flashlight cone. Kept slightly warm + tight.
    // (Intensities are in physical units — r155+ default — so they're high.)
    this.flashlight = new THREE.SpotLight(0xfff2d0, 22, 30, Math.PI / 7, 0.45, 1.4);
    this.flashlight.castShadow = false; // shadows from a moving light are costly
    this.flashTarget = new THREE.Object3D();
    this.scene.add(this.flashlight);
    this.scene.add(this.flashTarget);
    this.flashlight.target = this.flashTarget;
    this.flashOn = true;

    // A small fill light so the player isn't standing in a pure void.
    this.personalLight = new THREE.PointLight(0xfff0d8, 4, 5, 2);
    this.scene.add(this.personalLight);
  }

  toggleFlashlight() {
    this.flashOn = !this.flashOn;
    this.flashlight.visible = this.flashOn;
    return this.flashOn;
  }

  spawnAt(x, z, yaw = 0) {
    this.position.set(x, 0, z);
    this.velocityY = 0;
    this.yaw = yaw; this.pitch = 0;
  }

  /** Direction the camera is looking (normalized, includes pitch). */
  getForward(out = new THREE.Vector3()) {
    return this.camera.getWorldDirection(out);
  }
  /** Flattened look direction on the XZ plane (for streaming bias). */
  getForwardFlat(out = new THREE.Vector3()) {
    out.set(Math.sin(this.yaw) * -1, 0, Math.cos(this.yaw) * -1);
    return out.normalize();
  }
  get eyePosition() {
    return new THREE.Vector3(this.position.x, this.position.y + CFG.playerHeight + this._bobAmount, this.position.z);
  }

  look(dx, dy) {
    this.yaw   -= dx * CFG.mouseSensitivity;
    this.pitch -= dy * CFG.mouseSensitivity;
    this.pitch = clamp(this.pitch, -Math.PI / 2 + 0.05, Math.PI / 2 - 0.05);
  }

  update(dt, game) {
    if (!this.alive) return;
    const input = game.input;

    // ---- Weapon timers ----
    this._fireCd -= dt;
    if (this.reloading) {
      this._reloadT -= dt;
      if (this._reloadT <= 0) { this.ammo = CFG.weapon.magSize; this.reloading = false; }
    }

    // ---- Mouse look ----
    const m = input.consumeMouse();
    if (m.dx || m.dy) this.look(m.dx, m.dy);

    // ---- Desired horizontal movement in local space ----
    let mf = 0, ms = 0;
    if (input.isDown('KeyW')) mf += 1;
    if (input.isDown('KeyS')) mf -= 1;
    if (input.isDown('KeyD')) ms += 1;
    if (input.isDown('KeyA')) ms -= 1;

    const wantSprint = input.isDown('ShiftLeft') && mf > 0 && this.stamina > 1;
    const targetSpeed = wantSprint ? CFG.sprintSpeed : CFG.walkSpeed;

    // Convert local intent to world XZ using yaw.
    const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
    let vx = (-sin * mf + cos * ms);
    let vz = (-cos * mf - sin * ms);
    const len = Math.hypot(vx, vz);
    if (len > 0) { vx /= len; vz /= len; }

    const moveX = vx * targetSpeed * dt;
    const moveZ = vz * targetSpeed * dt;

    // ---- Collision-resolved horizontal move (axis-separated) ----
    this._moveAxis(moveX, 0, game);
    this._moveAxis(0, moveZ, game);

    // ---- Gravity / jump ----
    if (input.isDown('Space') && this.onGround) {
      this.velocityY = CFG.jumpSpeed; this.onGround = false;
    }
    this.velocityY -= CFG.gravity * dt;
    this.position.y += this.velocityY * dt;
    if (this.position.y <= 0) { this.position.y = 0; this.velocityY = 0; this.onGround = true; }

    // ---- Stamina ----
    if (wantSprint && len > 0) this.stamina = clamp(this.stamina - 22 * dt, 0, 100);
    else this.stamina = clamp(this.stamina + 12 * dt, 0, 100);

    // ---- Head bob + speed bookkeeping ----
    this.speed = len > 0 ? targetSpeed : 0;
    if (this.speed > 0 && this.onGround) {
      this._bobPhase += dt * (wantSprint ? 13 : 9);
      this._bobAmount = Math.sin(this._bobPhase) * (wantSprint ? 0.06 : 0.035);
    } else {
      this._bobAmount *= 0.85;
    }

    // ---- Noise emission (entities listen to this) ----
    let noise = 0;
    if (this.speed > 0) noise = wantSprint ? 0.95 : 0.45;
    if (!this.onGround) noise = Math.max(noise, 0.6);
    this.noiseLevel = noise;

    // ---- Sanity: drains in darkness / near threats, recovers in light ----
    const lit = this.flashOn || game.lightingExposure > 0.3;
    const threatNear = game.entityManager?.nearestThreatDistance(this.eyePosition) ?? Infinity;
    let sanityDelta = lit ? 1.5 : -2.0;
    if (threatNear < 12) sanityDelta -= (12 - threatNear) * 0.9;
    this.sanity = clamp(this.sanity + sanityDelta * dt, 0, 100);

    // ---- Apply camera transform ----
    this._applyCamera();
    this._updateViewmodel(dt);
  }

  // ---- Weapon actions -------------------------------------------------
  fire(game) {
    if (!this.alive || this.reloading || this._fireCd > 0) return;
    if (this.ammo <= 0) { game.audio.playEmptyClick(); this._fireCd = 0.25; return; }

    this.ammo--;
    this._fireCd = CFG.weapon.fireCooldown;
    this._recoil = 1;
    this._muzzleLight.intensity = 4;
    this._flash.material.opacity = 0.9;
    this._flash.rotation.z = Math.random() * Math.PI;
    game.audio.playPlayerShot();

    // Firing is LOUD — every shot pulls the entities toward you.
    game.entityManager.alertNoise(this.eyePosition, 16);
    this.noiseLevel = 1;

    // Hitscan vs entity "torso" spheres, requiring a clear wall line.
    const origin = this.eyePosition;
    const dir = this.getForward();
    const r = CFG.weapon.hitRadius;
    let best = null, bestT = Infinity;
    for (const e of game.entityManager.entities) {
      if (!e.alive || !e.isThreat) continue;
      const cx = e.position.x, cy = (e.height || 3) * 0.5, cz = e.position.z;
      const ox = cx - origin.x, oy = cy - origin.y, oz = cz - origin.z;
      const tca = ox * dir.x + oy * dir.y + oz * dir.z;
      if (tca < 0 || tca > CFG.weapon.range) continue;
      const perp2 = (ox * ox + oy * oy + oz * oz) - tca * tca;
      if (perp2 > r * r) continue;
      if (!game.chunkManager.segmentClear(origin.x, origin.z, cx, cz)) continue;
      if (tca < bestT) { bestT = tca; best = e; }
    }
    if (best) best.takeDamage(CFG.weapon.damage, game);
    return !!best;
  }

  reload(game) {
    if (this.reloading || this.ammo >= CFG.weapon.magSize) return;
    this.reloading = true;
    this._reloadT = CFG.weapon.reloadTime;
    game.audio.playReload();
  }

  _updateViewmodel(dt) {
    if (!this.viewModel) return;
    // Recoil recovers exponentially.
    this._recoil = Math.max(0, this._recoil - dt * 6);
    this._muzzleLight.intensity *= 0.8;
    this._flash.material.opacity *= 0.6;

    // Weapon sway eases toward the look delta + walking bob.
    this._vmSwayX += (0 - this._vmSwayX) * Math.min(1, dt * 6);
    const bob = (this.speed > 0 && this.onGround) ? Math.sin(this._bobPhase) * 0.012 : 0;
    const reloadDip = this.reloading ? Math.sin((1 - this._reloadT / CFG.weapon.reloadTime) * Math.PI) * 0.12 : 0;

    const base = this._vmBasePos;
    this.viewModel.position.set(
      base.x,
      base.y + bob - reloadDip,
      base.z + this._recoil * 0.05);
    this.viewModel.rotation.set(
      -this._recoil * 0.25 + reloadDip * 1.2,
      0,
      0);
  }

  _applyCamera() {
    const eye = this.eyePosition;
    this.camera.position.copy(eye);
    this.camera.rotation.set(0, 0, 0);
    this.camera.rotateY(this.yaw);
    this.camera.rotateX(this.pitch);

    // Flashlight rides the camera.
    this.flashlight.position.copy(eye);
    const dir = this.getForward();
    this.flashTarget.position.copy(eye).add(dir.multiplyScalar(6));
    this.personalLight.position.copy(eye);
  }

  // Move along a single world axis and push out of any wall AABB we overlap.
  _moveAxis(dx, dz, game) {
    this.position.x += dx;
    this.position.z += dz;
    const r = CFG.playerRadius;
    const colliders = game.chunkManager.collidersNear(this.position.x, this.position.z, 2);
    for (const c of colliders) {
      // Closest point on AABB to the player center.
      const cx = clamp(this.position.x, c.minX, c.maxX);
      const cz = clamp(this.position.z, c.minZ, c.maxZ);
      const ddx = this.position.x - cx;
      const ddz = this.position.z - cz;
      const d2 = ddx * ddx + ddz * ddz;
      if (d2 < r * r) {
        const d = Math.sqrt(d2) || 0.0001;
        const push = (r - d);
        this.position.x += (ddx / d) * push;
        this.position.z += (ddz / d) * push;
      }
    }
  }

  takeDamage(amount, game) {
    if (!this.alive) return;
    this.health = clamp(this.health - amount, 0, 100);
    game.onDamage?.(amount);
    if (this.health <= 0) { this.alive = false; game.onPlayerDeath?.(); }
  }
}
